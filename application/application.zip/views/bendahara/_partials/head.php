<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $profilsekolah['nama_lembaga'] ?? ''; ?></title>
<link rel="alternate icon" type="image/png" href="<?php echo base_url('assets/web/' . $logo); ?>">
<!-- Google Font: Source Sans Pro -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

<!-- Font Awesome Icons -->
<link rel="stylesheet" href="https://cdn.excode.my.id/assets/admin/plugins/fontawesome-free/css/all.min.css">
<!-- Bootstap -->
<link rel="stylesheet" href="https://cdn.excode.my.id/assets/admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
<!-- Toastr Alert -->
<link rel="stylesheet" href="https://cdn.excode.my.id/assets/admin/plugins/toastr/toastr.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="https://cdn.excode.my.id/assets/admin/css/adminlte.min.css">
<!-- Bootstrap Bundle dengan Popper -->


<link rel="stylesheet" href="https://cdn.excode.my.id/assets/admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="https://cdn.excode.my.id/assets/admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="https://cdn.excode.my.id/assets/admin/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css">
<link rel="stylesheet" href="https://cdn.excode.my.id/assets/admin/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
<link rel="stylesheet" href="https://cdn.excode.my.id/assets/admin/plugins/daterangepicker/daterangepicker.css">
<link rel="stylesheet" href="https://cdn.excode.my.id/assets/admin/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.excode.my.id/assets/admin/plugins/select2/css/select2.min.css">
<link rel="stylesheet" href="https://cdn.excode.my.id/assets/admin/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
<link rel="stylesheet" href="https://cdn.excode.my.id/assets/admin/plugins/bootstrap4-duallistbox/bootstrap-duallistbox.min.css">
<link rel="stylesheet" href="https://cdn.excode.my.id/assets/admin/plugins/bs-stepper/css/bs-stepper.min.css">
<link rel="stylesheet" href="https://cdn.excode.my.id/assets/admin/plugins/dropzone/min/dropzone.min.css">