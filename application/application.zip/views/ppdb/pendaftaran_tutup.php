<div class="container text-center py-5">
    <h1 class="display-4 text-danger mb-4"><i class="fas fa-times-circle"></i> Pendaftaran Ditutup</h1>
    <p class="lead">Maaf, pendaftaran PPDB sudah ditutup.</p>
    <p class="text-muted">Terima kasih atas minat Anda untuk bergabung dengan kami.<br>
        Silakan kunjungi situs kami secara berkala untuk informasi terbaru.</p>

    <a href="<?= site_url('landing/portalppdb') ?>" class="btn btn-primary mt-4">
        <i class="fas fa-home me-2"></i> Kembali ke Beranda
    </a>
</div>