<?php

class Landing extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Model_landing');
        $this->load->model('Auth_siswa');
        $this->load->library('form_validation');
        $this->load->library('pagination');
        $this->load->library('user_agent');
        $this->load->dbutil();

        // Dapatkan nama database dari konfigurasi
        $database_name = $this->db->database;

        if (!$this->dbutil->database_exists($database_name)) {
            // Jika database tidak ada, arahkan ke halaman instalasi
            redirect('install');
        }

        // Daftar tabel yang perlu diperiksa
        $tables = array('admin', 'berita', 'buku');

        foreach ($tables as $table) {
            if (!$this->db->table_exists($table)) {
                // Jika salah satu tabel tidak ada, arahkan ke halaman instalasi
                redirect('install');
            }
        }
    }

    public function index($page = 1)
    {
        if ($this->agent->is_mobile()) {
            // Load mobile view
            $view = 'halaman_mobile';
        } else {
            // Load desktop view
            $view = 'halaman_landing';
        }

        $config['base_url'] = base_url('landing/index');
        $config['total_rows'] = $this->Model_landing->count_all_ebooks();
        $config['per_page'] = 4;
        $config['uri_segment'] = 4;
        $config['use_page_numbers'] = TRUE;

        $this->pagination->initialize($config);

        $offset = ($page - 1) * $config['per_page'];
        $limit = $config['per_page'];


        $total_siswa                = $this->Model_landing->total_siswa();
        $total_guru                 = $this->Model_landing->total_guru();
        $total_kelas                = $this->Model_landing->total_kelas();
        $total_alumni               = $this->Model_landing->total_alumni();


        $data = array(
            'data_site'             => $this->Model_landing->get_site()->result(),
            'versi'                 => $this->Model_landing->get_version()->result(),
            'pengumumankelulusan'   => $this->Model_landing->get_site_with_status()->result(),
            'portalppdb'            => $this->Model_landing->get_portalppdb_with_status()->result(),
            'portalkelulusan'       => $this->Model_landing->get_portalkelulusan_with_status()->result(),
            'berita'                => $this->Model_landing->get_berita()->result(),
            'dataguru'              => $this->Model_landing->get_guru()->result(),
            'ebook'                 => $this->Model_landing->get_ebook($limit, $offset)->result(),
            'hasil_pencarian'       => null,
            'pagination_links'      => $this->pagination->create_links(),
            'page'                  => $page,
            "total_siswa"           => $total_siswa,
            "total_guru"            => $total_guru,
            "total_kelas"           => $total_kelas,
            "total_alumni"          => $total_alumni,
            'num_pages'             => ceil($config['total_rows'] / $config['per_page'])
        );

        $this->load->view('landing/' . $view, $data);
    }

    public function portalppdb()
    {
        if ($this->agent->is_mobile()) {
            // Load mobile view
            $view = 'portal_ppdb';
        } else {
            // Load desktop view
            $view = 'portal_ppdb';
        }

        $total_pendaftar = $this->Model_landing->total_pendaftar();
        $data = array(
            'data_site'         => $this->Model_landing->get_site()->result(),
            'versi'             => $this->Model_landing->get_version()->result(),
            'ppdb'              => $this->Model_landing->get_portalppdb()->result(),
            'jalur'             => $this->Model_landing->get_jalur()->result(),
            'jalurppdb'         => $this->Model_landing->get_jalurppdb()->result(),
            "total_pendaftar"   => $total_pendaftar
        );

        $this->load->view('landing/' . $view, $data);
    }



    public function portalkelulusan()
    {
        // Fungsi ini untuk menampilkan halaman portal kelulusan
        $data = array(
            'data_site' => $this->Model_landing->get_site()->result(),
            'kelulusan' => array(), // Data kelulusan awalnya kosong
            'target_time' => $this->_get_target_time() // Mendapatkan target time dari fungsi privat
        );

        // Load view 'portal_kelulusan' dengan data
        $this->load->view('landing/portal_kelulusan', $data);
    }

    private function _get_target_time()
    {
        // Mendapatkan target time dari database
        $target_time_data = $this->Model_landing->get_target_time();

        // Pastikan target_time valid sebelum digunakan
        if ($target_time_data && isset($target_time_data->target_time)) {
            return strtotime($target_time_data->target_time) * 1000; // Konversi ke milidetik untuk JavaScript
        } else {
            // Atur default target_time jika tidak ditemukan dari database
            return strtotime('2024-12-31T23:59:59') * 1000; // Misalnya
        }
    }





    // application/controllers/Landing.php


    public function cari_siswa()
    {
        if ($this->input->is_ajax_request()) {
            $nis = $this->input->post('nis');
    
            // Validasi NIS
            if (empty($nis)) {
                echo json_encode(['error' => 'NIS tidak boleh kosong']);
                return;
            }
    
            try {
                // Panggil model untuk melakukan pencarian siswa
                $kelulusan = $this->Model_landing->cari_siswa_dengan_nis($nis);
    
                // Mengatur header response
                header('Content-Type: application/json');
    
                // Menangani hasil pencarian
                if (empty($kelulusan)) {
                    echo json_encode(['error' => 'Siswa tidak ditemukan']);
                } else {
                    echo json_encode($kelulusan);
                }
            } catch (Exception $e) {
                echo json_encode(['error' => 'Terjadi kesalahan: ' . $e->getMessage()]);
            }
        } else {
            show_404();
        }
    }
    

    public function simpan_pesertappdb()
    {
        // Pastikan ini sesuai dengan input yang Anda kirim dari form
        $nama_pendaftar     = $this->input->post('nama_pendaftar', TRUE); // XSS filtering
        $nik                = $this->input->post('nik', TRUE); // XSS filtering
        $kk                 = $this->input->post('kk', TRUE); // XSS filtering
        $tempat_lahir       = $this->input->post('tempat_lahir', TRUE); // XSS filtering
        $tanggal_lahir      = $this->input->post('tanggal_lahir', TRUE); // XSS filtering
        $no_hp              = $this->input->post('no_hp', TRUE); // XSS filtering
        $jenis_kelamin      = $this->input->post('jenis_kelamin', TRUE); // XSS filtering
        $no_skhu            = $this->input->post('no_skhu', TRUE); // XSS filtering
        $asal_sekolah       = $this->input->post('asal_sekolah', TRUE); // XSS filtering
        $jalur              = $this->input->post('jalur', TRUE); // XSS filtering
        $nama_orang_tua     = $this->input->post('nama_orang_tua', TRUE); // XSS filtering
        $no_telp_orang_tua  = $this->input->post('no_telp_orang_tua', TRUE); // XSS filtering
        $kode_pin           = $this->input->post('kode_pin', TRUE); // XSS filtering
        $alamat_siswa       = $this->input->post('alamat_siswa', TRUE); // XSS filtering
        $rt                 = $this->input->post('rt', TRUE); // XSS filtering
        $rw                 = $this->input->post('rw', TRUE); // XSS filtering

        // Buat array untuk data yang akan disimpan ke database
        $insert_data = array(
            'nama_pendaftar'    => $nama_pendaftar,
            'nik'               => $nik,
            'kk'                => $kk,
            'tempat_lahir'      => $tempat_lahir,
            'tanggal_lahir'     => $tanggal_lahir,
            'no_hp'             => $no_hp,
            'jenis_kelamin'     => $jenis_kelamin,
            'no_skhu'           => $no_skhu,
            'asal_sekolah'      => $asal_sekolah,
            'jalur'             => $jalur,
            'nama_orang_tua'    => $nama_orang_tua,
            'no_telp_orang_tua' => $no_telp_orang_tua,
            'kode_pin'          => $kode_pin,
            'alamat_siswa'      => $alamat_siswa,
            'rt'                => $rt,
            'rw'                => $rw
        );

        // Panggil model untuk menyimpan data ke database
        $insert_result = $this->Model_landing->simpan_pesertappdb($insert_data);

        // Tindakan berdasarkan hasil penyimpanan
        if ($insert_result) {
            $this->session->set_flashdata('success_message', 'Data peserta berhasil mendaftar.');
        } else {
            $this->session->set_flashdata('error_message', 'Gagal menyimpan mendaftarkan peserta.');
        }

        // Redirect kembali ke halaman yang sesuai setelah proses selesai
        redirect('landing/portalppdb');
    }
}
