<?php

class Ppdb extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('admin');
        $this->load->model('Ppdb_Model');
        $this->load->model('auth_admin');
        $this->load->library('pagination');
        $this->load->library('upload');

        // Pemeriksaan apakah pengguna telah login
        $current_user = $this->auth_admin->current_user();
        if (!$current_user) {
            // Simpan URL halaman sebelumnya
            $this->session->set_userdata('previous_page', current_url());
            redirect('auth/loginadmin');
        }

        // Pemeriksaan apakah pengguna memiliki peran 'admin'
        if ($current_user->role != 'admin') {
            // Mengarahkan pengguna ke halaman kesalahan kustom
            $error_msg = 'Anda tidak diizinkan mengakses resources ini';
            show_error($error_msg, 403, 'Akses Ditolak');
        }
    }


    // FUNGSI PPDB
    public function Pendaftaranppdb()
    {
        $logo_data              = $this->admin->get_logo();
        $data['logo']           = $logo_data['logo'];
        $data['current_user']   = $this->auth_admin->current_user();
        $data['profilsekolah']  = $this->admin->get_profilsekolah_data();
        $data['ppdb']           = $this->Ppdb_Model->get_ppdb();
        $this->load->view('admin/ppdb/pendaftaranppdb', $data);
    }








    //FUNGSI JALUR PPDB
    public function jalurppdb()
    {
        $logo_data              = $this->admin->get_logo();
        $data['logo']           = $logo_data['logo'];
        $data['current_user']   = $this->auth_admin->current_user();
        $data['profilsekolah']  = $this->admin->get_profilsekolah_data();
        $data['ppdb']           = $this->Ppdb_Model->get_jalurppdb();
        $this->load->view('admin/ppdb/jalurppdb', $data);
    }


    public function get_jalurppdb()
    {
        $jalurppdb_id   = $this->input->get('jalurppdb_id');
        $jalurppdb      = $this->Ppdb_Model->get_jalurppdb_by_id($jalurppdb_id);
        echo json_encode(array('jalurppdb' => $jalurppdb));
    }


    public function update_jalurppdb()
    {
        $jalurppdb_id           = $this->input->post('editJalurppdbId');

        $data                   = array(
            'nama_jalur'        => $this->input->post('editNamaJalurppdb'),
            'kouta'             => $this->input->post('editKoutaJalur')

        );
        $result = $this->Ppdb_Model->update_jalurppdb($jalurppdb_id, $data);

        if ($result) {
            $this->session->set_flashdata('success_message', 'Data Jalur PPDB berhasil diperbarui.');
            echo json_encode(array('success' => true));
        } else {
            $this->session->set_flashdata('error_message', 'Tidak ada perubahan Data Jalur PPDB');
            echo json_encode(array('success' => false));
        }
    }


    public function hapus_jalurppdb($jalurppdb_id)
    {
        $result = $this->Ppdb_Model->hapus_jalurppdb($jalurppdb_id);
        if ($result) {
            $this->session->set_flashdata('error_message', 'Jalur PPDB berhasil dihapus.');
        } else {
            $this->session->set_flashdata('error_message', 'Gagal menghapus Jalur PPDB.');
        }
        redirect('admin/ppdb/jalurppdb');
    }













    //FUNGSI Pendaftaran Calon Siswa PPDB
    public function simpan_calonsiswa()
    {
        $nama_pendaftar     = $this->input->post('nama_pendaftar');
        $nik                = $this->input->post('nik');
        $kk                 = $this->input->post('kk');
        $jenis_kelamin      = $this->input->post('jenis_kelamin');
        $alamat_siswa       = $this->input->post('alamat_siswa');
        $no_hp              = $this->input->post('no_hp');
        $tempat_lahir       = $this->input->post('tempat_lahir');
        $tanggal_lahir      = $this->input->post('tanggal_lahir');
        $rt                 = $this->input->post('rt');
        $rw                 = $this->input->post('rw');
        $kecamatan          = $this->input->post('kecamatan');
        $kota               = $this->input->post('kota');



        $kode_pin           = $this->input->post('kode_pin');

        $existing_tiket     = $this->Ppdb_Model->get_ppdb_by_tiket($kode_pin);

        if ($existing_tiket) {
            $this->session->set_flashdata('error_message', 'Kode Tiket sudah tersedia. Silakan gunakan Kode Tiket lain.');
            redirect('admin/ppdb/pendaftaranppdb');
            return;
        }

        $insert_data = array(
            'nama_pendaftar'    => $nama_pendaftar,
            'nik'               => $nik,
            'kk'                => $kk,
            'jenis_kelamin'     => $jenis_kelamin,
            'alamat_siswa'      => $alamat_siswa,
            'no_hp'             => $no_hp,
            'tempat_lahir'      => $tempat_lahir,
            'tanggal_lahir'     => $tanggal_lahir,
            'rt'                => $rt,
            'rw'                => $rw,
            'kecamatan'         => $kecamatan,
            'kota'              => $kota,




            'kode_pin'          => $kode_pin
        );

        $insert_result = $this->Ppdb_Model->simpan_calonsiswa($insert_data);
        if ($insert_result) {
            $this->session->set_flashdata('success_message', 'Data Peserta PPDB berhasil disimpan.');
        } else {
            $this->session->set_flashdata('error_message', 'Gagal menyimpan data Peserta PPDB.');
        }

        redirect('admin/ppdb/pendaftaranppdb');
    }



    public function simpan_jalurppdb()
    {
        $nama_jalur     = $this->input->post('nama_jalur');
        $kouta          = $this->input->post('kouta');


        $insert_data = array(
            'nama_jalur'    => $nama_jalur,
            'kouta'        => $kouta
        );

        $insert_result = $this->Ppdb_Model->simpan_jalurppdb($insert_data);
        if ($insert_result) {
            $this->session->set_flashdata('success_message', 'Data Jalur PPDB berhasil disimpan.');
        } else {
            $this->session->set_flashdata('error_message', 'Gagal menyimpan data Jalur PPDB.');
        }

        redirect('admin/ppdb/jalurppdb');
    }





    public function update_calonsiswa()
    {
        $jalurppdb_id           = $this->input->post('editJalurppdbId');

        $data                   = array(
            'nama_jalur'        => $this->input->post('editNamaJalurppdb'),
            'kouta'             => $this->input->post('editKoutaJalur')

        );
        $result = $this->Ppdb_Model->update_jalurppdb($jalurppdb_id, $data);

        if ($result) {
            $this->session->set_flashdata('success_message', 'Data Jalur PPDB berhasil diperbarui.');
            echo json_encode(array('success' => true));
        } else {
            $this->session->set_flashdata('error_message', 'Tidak ada perubahan Data Jalur PPDB');
            echo json_encode(array('success' => false));
        }
    }



    public function hapus_calonsiswa($ppdb_id)
    {
        $result = $this->Ppdb_Model->hapus_calonsiswa($ppdb_id);
        if ($result) {
            $this->session->set_flashdata('error_message', 'Calon Siswa berhasil dihapus.');
        } else {
            $this->session->set_flashdata('error_message', 'Gagal menghapus Calon Siswa.');
        }
        redirect('admin/ppdb/pendaftaranppdb');
    }
















    public function settingppdb()
    {
        $data['current_user']   = $this->auth_admin->current_user();
        $data['logo']           = $this->admin->get_logo()['logo'];
        $data['logopemerintah'] = $this->admin->get_logopemerintah()['logopemerintah'];
        $data['profilsekolah']  = $this->admin->get_profilsekolah_data();
        $data['templateppdb']   = $this->Ppdb_Model->get_settingppdb();

        if ($this->input->post()) {
            $profilsekolah_data = array(
                'tanggal_start'     => $this->input->post('tanggal_start'),
                'tanggal_finis'     => $this->input->post('tanggal_finis'),
                'peraturan_ppdb'     => $this->input->post('peraturan_ppdb'),
                'status_ppdb'       => $this->input->post('status_ppdb')
            );

            $update_result = $this->Ppdb_Model->update_ppdb($profilsekolah_data);
            if ($update_result) {
                $this->session->set_flashdata('toast_message', 'Setting PPDB berhasil diperbarui');
            } else {
                $this->session->set_flashdata('toast_message', 'Tidak ada data yang diperbarui');
            }
            redirect('admin/ppdb/settingppdb');
        }

        // Memuat skrip CKEditor
        $ckeditor_script = '
        <script src="https://cdn.ckeditor.com/ckeditor5/34.0.0/classic/ckeditor.js"></script>
        <script>
            ClassicEditor
                .create(document.querySelector("#peraturan_ppdb"))
                .then(editor => {
                    console.log(editor);
                })
                .catch(error => {
                    console.error(error);
                });

            ClassicEditor
                .create(document.querySelector("#isi_skl"))
                .then(editor => {
                    console.log(editor);
                })
                .catch(error => {
                    console.error(error);
                });

           
        </script>
    ';

        // Menambahkan skrip CKEditor ke dalam data
        $data['ckeditor_script'] = $ckeditor_script;

        // Memuat tampilan bersamaan dengan skrip CKEditor
        $this->load->view('admin/ppdb/setting_ppdb', $data);
    }
}
