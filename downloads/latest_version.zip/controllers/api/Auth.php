<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model'); // Memuat model User_model
        $this->load->model('Perusahaan_model'); // Memuat model Perusahaan_model
    }

    public function login()
    {
        // Mendapatkan data dari request POST
        $json = file_get_contents('php://input');
        $data = json_decode($json);

        // Validasi input
        if (!isset($data->username) || !isset($data->password)) {
            $response = array(
                'status' => false,
                'message' => 'Username dan password harus diisi'
            );

            $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response));
            return;
        }

        $username = trim($data->username);
        $password = trim($data->password);

        // Memanggil model untuk mencari user berdasarkan username
        $user = $this->User_model->get_user_by_username($username);

        if ($user && password_verify($password, $user->password)) {
            // Memanggil model untuk mendapatkan nama lembaga dengan id = 1
            $nama_lembaga = $this->Perusahaan_model->get_nama_lembaga_by_id(1);

            // Jika nama lembaga ditemukan
            if ($nama_lembaga) {
                // Jika login berhasil
                $response = array(
                    'status' => true,
                    'message' => 'Login berhasil',
                    'data' => array(
                        'id_siswa' => $user->id_siswa,
                        'nama_siswa' => $user->nama_siswa,
                        'nama_kelas' => $user->nama_kelas,
                        'siswa_alamat' => $user->siswa_alamat,
                        'qrcode_siswa' => $user->qrcode_siswa,


                        'nama_lembaga' => $nama_lembaga
                    )
                );

                // Set session logged_in dan data pengguna
                $this->session->set_userdata('logged_in', true);
                $this->session->set_userdata('id_siswa', $user->id_siswa);
                $this->session->set_userdata('nama_siswa', $user->nama_siswa);
            } else {
                // Jika nama lembaga tidak ditemukan
                $response = array(
                    'status' => false,
                    'message' => 'Data lembaga tidak ditemukan'
                );
            }
        } else {
            // Jika login gagal
            $response = array(
                'status' => false,
                'message' => 'Username atau password salah'
            );
        }

        // Mengirim response dalam format JSON
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($response));
    }

    // Fungsi untuk proses logout
    public function logout()
    {
        // Hapus sesi atau token yang digunakan untuk autentikasi
        $this->session->unset_userdata('logged_in');
        $this->session->unset_userdata('id_siswa');
        $this->session->unset_userdata('nama_siswa');

        // Redirect ke halaman login atau halaman lain setelah logout
        redirect('auth/login');
    }

    // Fungsi untuk mengambil informasi lembaga
    public function getLembagaInfo()
    {
        // Mengambil informasi lembaga dari model Perusahaan_model
        $id_lembaga = 1;  // Ganti dengan id lembaga yang sesuai
        $nama_lembaga = $this->Perusahaan_model->get_nama_lembaga_by_id($id_lembaga);

        if ($nama_lembaga) {
            $response = array(
                'status' => true,
                'message' => 'Informasi lembaga berhasil ditemukan',
                'data' => array(
                    'namaLembaga' => $nama_lembaga
                )
            );
        } else {
            $response = array(
                'status' => false,
                'message' => 'Data lembaga tidak ditemukan'
            );
        }

        // Mengirim response dalam format JSON
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($response));
    }
}
