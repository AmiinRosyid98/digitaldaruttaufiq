<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Notification extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function sendNotification() {
        // Token OneSignal Anda
        $apiKey = 'M2FlZGZkNjEtZjUyMy00Njc5LWIwMGMtZDFkYWRlMzYyNmU5';

        // ID Pengguna (Player ID / User ID)
        $userId = '90a16994-570d-4ffb-910e-b8752862a9b2';

        // Judul dan isi pesan notifikasi
        $title = 'PEMBERITAHUAN SMARTSCHOOL';
        $message = 'Ini adalah pesan notifikasi dari CodeIgniter 3!';

        // Data yang akan dikirim dalam payload
        $data = array(
            'title' => $title,
            'message' => $message,
            // tambahkan data tambahan sesuai kebutuhan
        );

        // URL endpoint API OneSignal
        $url = 'https://onesignal.com/api/v1/notifications';

        // Data yang akan dikirim sebagai JSON
        $fields = json_encode(array(
            'app_id' => '1f42cd68-5689-49f8-9b98-fcb629fa1a3a',
            'include_player_ids' => array($userId),
            'data' => $data,
            'contents' => array(
                'en' => $message,
            ),
        ));

        // Konfigurasi cURL
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json; charset=utf-8',
            'Authorization: Basic ' . $apiKey,
        ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);

        // Eksekusi cURL dan ambil respons
        $response = curl_exec($ch);
        curl_close($ch);

        // Tampilkan hasil respons (opsional)
        echo $response;
    }
}