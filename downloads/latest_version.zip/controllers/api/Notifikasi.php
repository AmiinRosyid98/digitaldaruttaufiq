<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Notifikasi extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        // Load library atau helper yang dibutuhkan
        $this->load->library('firebase');
    }

    public function kirimNotifikasi()
    {
        // Mengambil token perangkat dari database (contoh: tabel siswa)
        $tokens = $this->db->select('fcm_token')->get('siswa')->result_array();

        // Pesan notifikasi
        $message = [
            'title' => 'Judul Notifikasi',
            'body' => 'Isi notifikasi yang ingin Anda kirim',
            'click_action' => 'OPEN_ACTIVITY_1'  // Action untuk menavigasi aplikasi ke activity tertentu
        ];

        // Mengirim notifikasi ke setiap token perangkat
        foreach ($tokens as $token) {
            $this->firebase->sendNotification($token['fcm_token'], $message);
        }

        // Respon sukses atau gagal sesuai kebutuhan
        echo "Notifikasi berhasil dikirim!";
    }
}
