<?php
// File: application/models/Admin.php

class Arsipguru_Model extends CI_Model
{


    private $_tablekelas = "arsip_banksoal";
    const SESSION_KEY = 'admin_id';



    public function get_arsip($order_by = 'id', $order_type = 'ASC')
    {
        $this->db->select('arsip_banksoal.*, ptk.nama_ptk');
        $this->db->from('arsip_banksoal');
        $this->db->join('ptk', 'arsip_banksoal.id_guru = ptk.id_guru', 'left');
        $this->db->order_by($order_by, $order_type);
        $query = $this->db->get();

        return $query->result_array();
    }


    public function get_arsiptimeline($order_by = 'timestamp_arsip', $order_type = 'DESC')
    {
        $this->db->select('arsip_banksoal.*, ptk.nama_ptk');
        $this->db->from('arsip_banksoal');
        $this->db->join('ptk', 'arsip_banksoal.id_guru = ptk.id_guru', 'left');
        $this->db->order_by($order_by, $order_type);
        $this->db->limit(4); // Menambahkan batasan jumlah data menjadi 4
        $query = $this->db->get();

        return $query->result_array();
    }
}
