<?php
// File: application/models/Admin.php

class Ppdb_Model extends CI_Model
{

    private $_tableperusahaan = "perusahaan";
    private $_tablesite = "site";
    private $_table = "admin";
    const SESSION_KEY = 'admin_id';


    //Fungsi PPDB

    public function get_ppdb()
    {
        //$this->db->order_by('nourut_mapel', 'ASC');
        $query = $this->db->get('ppdb');
        return $query->result_array();
    }


    public function simpan_calonsiswa($data)
    {
        $this->db->insert('ppdb', $data);
        return $this->db->affected_rows() > 0;
    }

    public function get_ppdb_by_tiket($kode_pin)
    {
        $this->db->where('kode_pin', $kode_pin);
        $query = $this->db->get('ppdb');
        return $query->row();
    }

    public function hapus_calonsiswa($ppdb_id)
    {
        $this->db->where('id', $ppdb_id);
        $result = $this->db->delete('ppdb');
        return $result;
    }





    // JALUR PPDB
    public function get_jalurppdb()
    {
        $query = $this->db->get('ppdbjalur');
        return $query->result_array();
    }


    public function simpan_jalurppdb($data)
    {
        $this->db->insert('ppdbjalur', $data);
        return $this->db->affected_rows() > 0;
    }


    public function get_jalurppdb_by_id($jalurppdb_id)
    {
        return $this->db->get_where('ppdbjalur', array('id' => $jalurppdb_id))->row_array();
    }


    public function update_jalurppdb($jalurppdb_id, $data)
    {
        $this->db->where('id', $jalurppdb_id);
        $this->db->update('ppdbjalur', $data);
        return $this->db->affected_rows() > 0;
    }

    public function hapus_jalurppdb($jalurppdb_id)
    {
        $this->db->where('id', $jalurppdb_id);
        $result = $this->db->delete('ppdbjalur');
        return $result;
    }






    //Fungsi Setting PPDB
    public function get_settingppdb()
    {
        return $this->db->get('templateppdb')->row_array();
    }

    public function update_ppdb($profilsekolah_data)
    {
        $seetingppdb_id = 1; // Gantilah dengan ID perusahaan yang sesuai
        $this->db->where('id', $seetingppdb_id);
        return $this->db->update('templateppdb', $profilsekolah_data);
    }













    public function get_mapel_by_id($mapel_id)
    {
        return $this->db->get_where('mapel', array('id_mapel' => $mapel_id))->row_array();
    }






    public function update_mapel($mapel_id, $data)
    {
        $this->db->where('id_mapel', $mapel_id);
        $this->db->update('mapel', $data);
        return $this->db->affected_rows() > 0;
    }
}
