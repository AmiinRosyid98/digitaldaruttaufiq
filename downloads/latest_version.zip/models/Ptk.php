<?php
// File: application/models/Admin.php

class Ptk extends CI_Model
{

    private $_tableperusahaan = "perusahaan";
    private $_tablesite = "site";
    private $_table = "ptk";
    const SESSION_KEY = 'ptk_id';


    public function get_dataguru($id_guru)
    {
        $this->db->select('*');
        $this->db->from('ptk');
        $this->db->where('id_guru', $id_guru);
        $query = $this->db->get();
        return $query->row_array(); // Mengembalikan satu baris data sebagai array asosiatif
    }

    public function update_qr_code_path($id_guru, $qr_code_path)
    {
        $data = array(
            'qrcode_ptk' => $qr_code_path
        );

        $this->db->where('id_guru', $id_guru);
        $this->db->update('ptk', $data);
    }

    public function get_kelasmengajar($id_guru)
    {
        $this->db->select('*');
        $this->db->from('ptk');
        //$this->db->join('kelas', 'ptk.id_guru = kelas.no_kelas');
        $this->db->join('kelas', 'FIND_IN_SET(kelas.no_kelas, ptk.kode_kelas) > 0', 'LEFT');
        $this->db->where('ptk.id_guru', $id_guru);
        $query = $this->db->get();
        return $query->result_array();
    }



    public function count_siswa_by_kelas($kelas_id)
    {
        $this->db->where('kode_kelas', $kelas_id);
        $this->db->where('siswa.status_kelulusan', 0);
        $this->db->from('siswa');
        return $this->db->count_all_results();
    }




    public function update_profile($id, $data)
    {
        $this->db->where('id', $id);
        $this->db->update($this->_table, $data);
        return $this->db->affected_rows() > 0;
    }


    public function update_avatar($user_id, $avatar_filename)
    {
        $data = array(
            'avatar' => $avatar_filename
        );

        $this->db->where('id', $user_id);
        $this->db->update($this->_table, $data);

        return $this->db->affected_rows() > 0;
    }







    //Fungsi Profil Sekolah
    public function get_profilsekolah_data()
    {
        return $this->db->get('perusahaan')->row_array();
    }

    public function get_logo()
    {
        $query = $this->db->get($this->_tableperusahaan); // Mengambil data dari tabel
        return $query->row_array(); // Mengembalikan satu baris data sebagai array
    }

    public function get_logopemerintah()
    {
        $query = $this->db->get($this->_tableperusahaan); // Mengambil data dari tabel
        return $query->row_array(); // Mengembalikan satu baris data sebagai array
    }







    //Fungsi Siswa
    public function get_siswa()
    {
        $this->db->select('*');
        $this->db->from('siswa');
        $this->db->join('kelas', 'siswa.kode_kelas = kelas.no_kelas');
        $this->db->order_by('nama_kelas', 'ASC');
        $this->db->order_by('no_absen');
        $query = $this->db->get();
        return $query->result_array();
    }



    public function simpan_siswa($data)
    {
        $this->db->insert('siswa', $data);
        return $this->db->affected_rows() > 0;
    }

    public function get_siswa_by_id($siswa_id)
    {
        return $this->db->get_where('siswa', array('id' => $siswa_id))->row_array();
    }
}
