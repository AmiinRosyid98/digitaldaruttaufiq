<html lang="en">

<head>

    <?php $this->load->view('admin/_partials/head.php') ?>
</head>

<body>
    <?php
    // Ambil pesan flash success
    $success_message = $this->session->flashdata('success_message');
    // Ambil pesan flash error
    $error_message = $this->session->flashdata('error_message');
    // Ambil pesan flash info
    $info_message = $this->session->flashdata('info_message');
    ?>

    <body class="hold-transition sidebar-mini layout-fixed layout-footer-fixed">
        <div class="wrapper">
            <!-- Navbar -->
            <?php $this->load->view('admin/_partials/navbar.php') ?>
            <!-- /.navbar -->


            <aside class="main-sidebar elevation-4 sidebar-dark-<?php echo $profilsekolah['menu_active'] ?? ''; ?>" style="background-color: <?php echo $profilsekolah['bg_active'] ?? ''; ?>;">
                <!-- Sidebar Information -->
                <?php $this->load->view('admin/_partials/sidebar_information.php') ?>

                <!-- Sidebar Menu -->
                <?php $this->load->view('admin/_partials/sidebar_menu.php') ?>

            </aside>

            <!-- ======================================================================================================= -->
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <div class="content-header">
                    <div class="container-fluid">

                    </div>
                </div>
                <!-- isi content -->
                <div class="content">

                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex justify-content-between align-items-center">
                                <h3 class="card-title">Jalur Pendaftaran PPDB </h3>
                                <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#tambahmapelModal">
                                    Tambah Data
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr class="text-center">
                                        <th>No</th>
                                        <th>Jalur Pendaftaran</th>
                                        <th>Kouta Diterima</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($ppdb as $index => $datajalur) : ?>
                                        <tr>
                                            <td class="text-center"><?php echo $index + 1; ?></td>
                                            <td class="text-center" style="font-weight: bold;"><?php echo $datajalur['nama_jalur']; ?></td>
                                            <td class="text-center" style="font-weight: bold;"><?php echo $datajalur['kouta']; ?></td>
                                            <td class="text-center">
                                                <a class="btn btn-danger btn-sm" href="#" onclick="deleteJalurppdb(<?php echo $datajalur['id']; ?>)"><i class="fas fa-trash"></i></a>
                                                <a class="btn btn-success btn-sm" href="#" onclick="editJalurppdb(<?php echo $datajalur['id']; ?>)"><i class="fas fa-edit"></i></a>

                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>

                            <div class="pagination">
                                <?php echo $this->pagination->create_links(); ?>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

            <!-- ======================================================================================================= -->

            <!-- Modal Tambah Mapel -->
            <div class="modal fade" id="tambahmapelModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Inpur Data Manual</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo site_url('admin/ppdb/simpan_jalurppdb'); ?>" method="POST">
                                <div style="display: flex; justify-content: space-between;">
                                    <!-- Bagian kiri -->
                                    <div style="flex: 1; margin-right: 20px;">
                                        <div class="form-group">
                                            <label for="nama_jalur">Jalur Pendaftaran</label>
                                            <input type="text" class="form-control" id="nama_jalur" name="nama_jalur" placeholder="Prestasi" required>
                                        </div>


                                    </div>

                                    <!-- Bagian kanan -->
                                    <div style="flex: 1;">
                                        <div class="form-group">
                                            <label for="kouta">Kouta Diterima</label>
                                            <input type="number" class="form-control" id="kouta" name="kouta" required>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary">Simpan</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal Edit Mapel -->
            <div class="modal fade" id="editJalurppdbModal" tabindex="-1" role="dialog" aria-labelledby="editJalurPpdbModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editJalurPpdbModalLabel">Edit Jalur PPDB</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form id="editJalurPpdbForm">
                            <div class="modal-body">
                                <input type="hidden" id="editJalurppdbId" name="editJalurppdbId">
                                <div class="form-group">
                                    <label for="editNamaJalurppdb">Nama Jalur</label>
                                    <input type="text" class="form-control" id="editNamaJalurppdb" name="editNamaJalurppdb" required>
                                </div>
                                <div class="form-group">
                                    <label for="editKoutaJalur">Kouta</label>
                                    <input type="number" class="form-control" id="editKoutaJalur" name="editKoutaJalur" required>
                                </div>



                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>









            <?php $this->load->view('admin/_partials/footer.php') ?>

            <script>
                //Fungsi Edit Mapel
                function editJalurppdb(jalurppdbId) {
                    $.ajax({
                        url: 'get_jalurppdb',
                        type: 'GET',
                        data: {
                            jalurppdb_id: jalurppdbId
                        },
                        dataType: 'json',
                        success: function(response) {
                            $('#editJalurppdbId').val(response.jalurppdb.id);
                            $('#editNamaJalurppdb').val(response.jalurppdb.nama_jalur);
                            $('#editKoutaJalur').val(response.jalurppdb.kouta);
                            $('#editJalurppdbModal').modal('show');
                        },
                        error: function() {
                            alert('Gagal memuat data Jalur PPDB.');
                        }
                    });
                }


                $(document).ready(function() {
                    $('#editJalurPpdbForm').submit(function(event) {
                        event.preventDefault();

                        $.ajax({
                            url: 'update_jalurppdb',
                            type: 'POST',
                            data: $(this).serialize(),
                            dataType: 'json',
                            success: function(response) {
                                if (response.success) {
                                    $('#editJalurppdbModal').modal('hide');
                                    showToast('success', 'Data Jalur PPDB berhasil diperbarui.');
                                    location.reload();
                                } else {
                                    showToast('error', 'Gagal menyimpan perubahan.');
                                }
                            },
                            error: function() {
                                showToast('error', 'Terjadi kesalahan saat menyimpan perubahan.');
                            }
                        });
                    });
                });

                function showToast(type, message) {
                    toastr.options.positionClass = 'toast-top-right';
                    toastr[type](message);
                }
            </script>

            <script>
                //Fungsi Hapus Tingkat
                function deleteJalurppdb(ppdblId) {
                    Swal.fire({
                        title: 'Apakah Anda yakin?',
                        text: "Jalur PPDB akan terhapus permanen !",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#d33',
                        cancelButtonColor: '#3085d6',
                        confirmButtonText: 'Ya, hapus!',
                        cancelButtonText: 'Batal'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = "<?php echo base_url('/admin/ppdb/hapus_jalurppdb/'); ?>" + ppdblId;
                        }
                    });
                }
            </script>




            <script>
                // Form Generate Tiekt PPDB
                $(document).ready(function() {
                    generateAndSetRandomCode();

                    $('#generateKode').click(function() {
                        generateAndSetRandomCode();
                    });

                    function generateAndSetRandomCode() {
                        var randomCode = generateRandomCode();
                        $('#kodeLayanan').val(randomCode);
                    }

                    function generateRandomCode() {
                        var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
                        var codeLength = 5;
                        var randomCode = 'PPDB-';

                        // Mendapatkan tahun saat ini
                        var year = new Date().getFullYear();

                        // Menambahkan tahun saat ini ke dalam randomCode
                        randomCode += year + '-';

                        // Generate kode acak
                        for (var i = 0; i < codeLength; i++) {
                            randomCode += chars.charAt(Math.floor(Math.random() * chars.length));
                        }

                        return randomCode;
                    }

                });
            </script>

            <script>
                function showToast(type, message) {
                    toastr.options.positionClass = 'toast-top-right';
                    toastr[type](message);
                }

                <?php if ($success_message) : ?>
                    showToast('success', '<?php echo $success_message; ?>');
                <?php endif; ?>

                <?php if ($info_message) : ?>
                    showToast('info', '<?php echo $info_message; ?>');
                <?php endif; ?>

                <?php if ($error_message) : ?>
                    showToast('error', '<?php echo $error_message; ?>');
                <?php endif; ?>
            </script>