<html lang="en">

<head>

    <?php $this->load->view('admin/_partials/head.php') ?>
</head>

<body>
    <?php
    // Ambil pesan flash success
    $success_message = $this->session->flashdata('success_message');
    // Ambil pesan flash error
    $error_message = $this->session->flashdata('error_message');
    // Ambil pesan flash info
    $info_message = $this->session->flashdata('info_message');
    ?>

    <body class="hold-transition sidebar-mini layout-fixed layout-footer-fixed">
        <div class="wrapper">
            <!-- Navbar -->
            <?php $this->load->view('admin/_partials/navbar.php') ?>
            <!-- /.navbar -->


            <aside class="main-sidebar elevation-4 sidebar-dark-<?php echo $profilsekolah['menu_active'] ?? ''; ?>" style="background-color: <?php echo $profilsekolah['bg_active'] ?? ''; ?>;">
                <!-- Sidebar Information -->
                <?php $this->load->view('admin/_partials/sidebar_information.php') ?>

                <!-- Sidebar Menu -->
                <?php $this->load->view('admin/_partials/sidebar_menu.php') ?>

            </aside>

            <!-- ======================================================================================================= -->
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <div class="content-header">
                    <div class="container-fluid">
                        <div class="row mb-2">
                            <div class="col-sm-6">
                                <h1 class="m-0"></h1>
                            </div>
                            <div class="col-sm-6">
                                <ol class="breadcrumb float-sm-right">
                                    <li class="breadcrumb-item"><a href="#">Data</a></li>
                                    <li class="breadcrumb-item active">PPDB</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- isi content -->
                <div class="content">

                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex justify-content-between align-items-center">
                                <h3 class="card-title">Data PPDB </h3>
                                <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#tambahmapelModal">
                                    Tambah Data
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr class="text-center">
                                        <th>No</th>
                                        <th>Nama Pendaftar</th>
                                        <th>Asal Sekolah</th>
                                        <th>Nomor Pendaftaran</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($ppdb as $index => $datasiswa) : ?>
                                        <tr>
                                            <td class="text-center"><?php echo $index + 1; ?></td>
                                            <td class="text-center" style="font-weight: bold;"><?php echo $datasiswa['nama_pendaftar']; ?></td>
                                            <td class="text-center" style="font-weight: bold;"><?php echo $datasiswa['asal_sekolah']; ?></td>
                                            <td class="text-center" style="font-weight: bold;"><?php echo $datasiswa['kode_pin']; ?></td>

                                            <td class="text-center">
                                                <a class="btn btn-danger btn-sm" href="#" onclick="deleteCalomsiswa(<?php echo $datasiswa['id']; ?>)"><i class="fas fa-trash"></i></a>
                                                <a class="btn btn-success btn-sm" href="#" onclick="editCalonSiswa(<?php echo $datasiswa['id']; ?>)"><i class="fas fa-edit"></i></a>

                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>

                            <div class="pagination">
                                <?php echo $this->pagination->create_links(); ?>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

            <!-- ======================================================================================================= -->

            <!-- Modal Tambah Mapel -->
            <div class="modal fade" id="tambahmapelModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Inpur Data Manual</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo site_url('admin/ppdb/simpan_calonsiswa'); ?>" method="POST">
                                <div style="display: flex; justify-content: space-between;">
                                    <!-- Bagian kiri -->
                                    <div style="flex: 1; margin-right: 20px;">
                                        <div class="form-group">
                                            <label for="kodeLayanan">Generate Tiket</label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" id="kodeLayanan" name="kode_pin" required readonly>
                                                <div class="input-group-append">
                                                    <button type="button" class="btn btn-secondary" id="generateKode">Generate Kode</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="nik">Nomor NIK</label>
                                            <input type="text" class="form-control" id="nik" name="nik" placeholder="Nomor NIK" required>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label for="jenis_kelamin">Jenis Kelamin</label>
                                                <select class="form-control" id="jenis_kelamin" name="jenis_kelamin" required>
                                                    <option value="L">Laki-laki</option>
                                                    <option value="P">Perempuan</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="alamat_siswa">Alamat Rumah</label>
                                            <textarea class="form-control" id="alamat_siswa" name="alamat_siswa" rows="5" placeholder="Alamat Rumah" required></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label for="no_hp">Nomor Telepon</label>
                                            <input type="text" class="form-control" id="no_hp" name="no_hp" placeholder="Nomor Telepon" required>
                                        </div>


                                    </div>

                                    <!-- Bagian kanan -->
                                    <div style="flex: 1;">
                                        <div class="form-group">
                                            <label for="nama_pendaftar">Nama Pendaftar</label>
                                            <input type="text" class="form-control" id="nama_pendaftar" name="nama_pendaftar" placeholder="Nama Calon Siswa" required>
                                        </div>

                                        <div class="form-group">
                                            <label for="kk">Nomor KK (Kartu Keluarga)</label>
                                            <input type="text" class="form-control" id="kk" name="kk" placeholder="Nomor KK" required>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="tempat_lahir">Tempat Lahir</label>
                                                <input type="text" class="form-control" id="tempat_lahir" name="tempat_lahir" placeholder="Tempat Lahir" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="tanggal_lahir">Tanggal Lahir</label>
                                                <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir" required>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-4">
                                                <label for="rt">RT</label>
                                                <input type="text" class="form-control" id="rt" name="rt" required>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="rw">RW</label>
                                                <input type="text" class="form-control" id="rw" name="rw" required>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="kecamatan">Kecamatan</label>
                                                <input type="text" class="form-control" id="kecamatan" name="kecamatan" required>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="kota">Kota / Kabupaten</label>
                                                <input type="text" class="form-control" id="kota" name="kota" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="provinsi">Provinsi</label>
                                                <input type="text" class="form-control" id="provinsi" name="provinsi" required>
                                            </div>
                                        </div>



                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary">Simpan</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal Edit Calon Siswa -->
            <div class="modal fade" id="editMapelModal" tabindex="-1" role="dialog" aria-labelledby="editMapelModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editMapelModalLabel">Edit Calon Pendaftar</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form id="editMapelForm">
                            <div class="modal-body">
                                <input type="hidden" id="editMapelId" name="editMapelId">
                                <div class="form-group">
                                    <label for="editNamaSiswa">Nama Siswa</label>
                                    <input type="text" class="form-control" id="editNamaSiswa" name="editNamaSiswa" required>
                                </div>



                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>









            <?php $this->load->view('admin/_partials/footer.php') ?>

            <script>
                //Fungsi Edit Mapel
                function editCalonSiswa(calonsiswalId) {
                    $.ajax({
                        url: 'get_calonsiswa',
                        type: 'GET',
                        data: {
                            calonsiswa_id: calonsiswalId
                        },
                        dataType: 'json',
                        success: function(response) {
                            $('#editMapelId').val(response.mapel.id_mapel);
                            $('#editNamaMapel').val(response.mapel.nama_mapel);
                            $('#editKelompokMapel').val(response.mapel.kelompok_mapel);
                            $('#editNourutMapel').val(response.mapel.nourut_mapel);
                            $('#editMapelModal').modal('show');
                        },
                        error: function() {
                            alert('Gagal memuat data Mapel.');
                        }
                    });
                }


                $(document).ready(function() {
                    $('#editMapelForm').submit(function(event) {
                        event.preventDefault();

                        $.ajax({
                            url: 'update_mapel',
                            type: 'POST',
                            data: $(this).serialize(),
                            dataType: 'json',
                            success: function(response) {
                                if (response.success) {
                                    $('#editMapelModal').modal('hide');
                                    showToast('success', 'Data Mapel berhasil diperbarui.');
                                    location.reload();
                                } else {
                                    showToast('error', 'Gagal menyimpan perubahan.');
                                }
                            },
                            error: function() {
                                showToast('error', 'Terjadi kesalahan saat menyimpan perubahan.');
                            }
                        });
                    });
                });

                function showToast(type, message) {
                    toastr.options.positionClass = 'toast-top-right';
                    toastr[type](message);
                }
            </script>

            <script>
                //Fungsi Hapus Tingkat
                function deleteCalomsiswa(ppdblId) {
                    Swal.fire({
                        title: 'Apakah Anda yakin?',
                        text: "Calon Siswa ini akan terhapus permanen !",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#d33',
                        cancelButtonColor: '#3085d6',
                        confirmButtonText: 'Ya, hapus!',
                        cancelButtonText: 'Batal'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = "<?php echo base_url('/admin/ppdb/hapus_calonsiswa/'); ?>" + ppdblId;
                        }
                    });
                }
            </script>




            <script>
                // Form Generate Tiekt PPDB
                $(document).ready(function() {
                    generateAndSetRandomCode();

                    $('#generateKode').click(function() {
                        generateAndSetRandomCode();
                    });

                    function generateAndSetRandomCode() {
                        var randomCode = generateRandomCode();
                        $('#kodeLayanan').val(randomCode);
                    }

                    function generateRandomCode() {
                        var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
                        var codeLength = 5;
                        var randomCode = 'PPDB-';

                        // Mendapatkan tahun saat ini
                        var year = new Date().getFullYear();

                        // Menambahkan tahun saat ini ke dalam randomCode
                        randomCode += year + '-';

                        // Generate kode acak
                        for (var i = 0; i < codeLength; i++) {
                            randomCode += chars.charAt(Math.floor(Math.random() * chars.length));
                        }

                        return randomCode;
                    }

                });
            </script>

            <script>
                function showToast(type, message) {
                    toastr.options.positionClass = 'toast-top-right';
                    toastr[type](message);
                }

                <?php if ($success_message) : ?>
                    showToast('success', '<?php echo $success_message; ?>');
                <?php endif; ?>

                <?php if ($info_message) : ?>
                    showToast('info', '<?php echo $info_message; ?>');
                <?php endif; ?>

                <?php if ($error_message) : ?>
                    showToast('error', '<?php echo $error_message; ?>');
                <?php endif; ?>
            </script>