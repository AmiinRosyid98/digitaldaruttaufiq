<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install Database</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .toast {
            position: fixed;
            top: 1rem;
            right: 1rem;
            z-index: 9999;
            max-width: 300px;
        }
    </style>
</head>

<body class="bg-gray-100 min-h-screen flex items-center justify-center">
    <div class="bg-white p-6 rounded-lg shadow-md max-w-md w-full relative">
        <h1 class="text-3xl font-semibold mb-4">Install Database</h1>
        <p class="text-gray-700 mb-4">Anda akan melakukan instalasi SMARTSCHOOL.</p>

        <?php if (!empty($message)) : ?>
            <?php if (strpos($message, 'successfully') !== false) : ?>
                <div class="toast bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded" role="alert">
                    <strong class="font-bold">Success!</strong>
                    <span class="block sm:inline"><?php echo $message; ?></span>
                </div>
            <?php elseif (strpos($message, 'Failed') !== false) : ?>
                <div class="toast bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded" role="alert">
                    <strong class="font-bold">Oops!</strong>
                    <span class="block sm:inline"><?php echo $message; ?></span>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <form action="<?php echo site_url('install/execute'); ?>" method="post">
            <div class="mb-4">
                <label class="block text-gray-700 mb-2">
                    <input type="checkbox" name="confirm_install" class="mr-2 leading-tight" required>
                    <span class="text-sm">Saya Setuju untuk melanjutkan instalasi Database</span>
                </label>
                <?php echo form_error('confirm_install', '<p class="text-red-500 text-xs italic">', '</p>'); ?>
            </div>
            <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Install</button>
        </form>
    </div>
</body>

</html>