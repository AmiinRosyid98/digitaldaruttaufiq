<!DOCTYPE html>
<html lang="id">
<?php foreach ($data_site as $res) { ?> <?php } ?>
<?php foreach ($versi as $version) { ?> <?php } ?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $nama_lembaga = htmlspecialchars($res->nama_lembaga, ENT_QUOTES, 'UTF-8'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="alternate icon" type="image/png" href="<?php echo  base_url() ?>assets/web/<?php echo $res->logo; ?>">
    <script src="https://kit.fontawesome.com/c67daa5af8.js" crossorigin="anonymous"></script><!-- Bootstap -->

    <meta name="description" content="Aplikasi SMARTSCHOOL <?php echo $nama_lembaga = htmlspecialchars($res->nama_lembaga, ENT_QUOTES, 'UTF-8'); ?>">
    <meta name="keywords" content="smartschool, <?php echo $nama_lembaga = htmlspecialchars($res->nama_lembaga, ENT_QUOTES, 'UTF-8'); ?>, aplikasi smartschool <?php echo $nama_lembaga = htmlspecialchars($res->nama_lembaga, ENT_QUOTES, 'UTF-8'); ?>">
    <!-- Open Graph Meta Tags for social media -->
    <meta property="og:title" content="<?php echo $nama_lembaga = htmlspecialchars($res->nama_lembaga, ENT_QUOTES, 'UTF-8'); ?>">
    <meta property="og:description" content="aplikasi manajemen sekolah berbasis digital penunjang kegiatan sekolah">
    <meta property="og:image" content="<?php echo base_url() ?>assets/web/<?php echo $res->logo; ?>">
    <meta property="og:url" content="URL situs Anda">
    <meta property="og:type" content="website">

    <!-- Twitter Meta Tags -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo $nama_lembaga = htmlspecialchars($res->nama_lembaga, ENT_QUOTES, 'UTF-8'); ?>">
    <meta name="twitter:description" content="aplikasi manajemen sekolah berbasis digital penunjang kegiatan sekolah">
    <meta name="twitter:image" content="<?php echo base_url() ?>assets/web/<?php echo $res->logo; ?>">

    <!-- Additional Meta Tags for SEO -->
    <meta name="description" content="SmartSchool adalah portal pendidikan terpadu yang menyediakan berbagai informasi dan layanan sekolah.">
    <meta name="keywords" content="SmartSchool, Excode, pendidikan, sekolah, portal pendidikan">
    <meta name="author" content="<?php echo $nama_lembaga = htmlspecialchars($res->nama_lembaga, ENT_QUOTES, 'UTF-8'); ?>">

    <style>
        .counter {
            font-size: 2rem;
            font-weight: bold;
        }
    </style>

    <style>
        .hero {
            background-image: url('https://cdn.excode.my.id/assets/landing/bg6.png');
            background-size: cover;
            background-position: center;
            height: 60vh;
            display: flex;
            align-items: center;
            color: white;
        }
    </style>
    <style>
        .carousel-img {
            height: 230px;
            /* Tinggi gambar disesuaikan agar tidak terlalu besar */
            object-fit: cover;
            /* Agar gambar terisi di dalam kotak dengan proporsi yang tepat */
            max-width: 100%;
            /* Lebar gambar diatur agar sesuai dengan lebar kolom */
            margin: 0 auto;
            /* Posisi gambar di tengah kolom */
        }

        /* Custom CSS for dropdown menus */
        .dropdown-menu {
            font-size: 14px;
            /* Ukuran font */
            width: 700px;
            /* Lebar menu dropdown */
            padding: 10px;
            /* Padding di dalam menu */
            border: 1px solid #ccc;
            /* Garis border */
            background-color: #fff;
            /* Warna latar belakang */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            /* Bayangan (shadow) */
            border-radius: 5px;
            /* Sudut bulatan */
        }

        .dropdown-menu li {
            list-style-type: none;
            /* Hilangkan bullet list */
            margin-bottom: 10px;
            /* Jarak antar item */
        }

        .dropdown-menu li a {
            color: #333;
            /* Warna teks */
            text-decoration: none;
            /* Hilangkan underline */
            display: block;
            /* Menjadikan link sebagai blok */
            padding: 10px;
            /* Padding di dalam link */
        }

        .dropdown-menu li a:hover {
            background-color: #f0f0f0;
            /* Warna latar belakang saat hover */
        }

        .card-hover {
            transition: background-color 0.3s ease;
        }

        .card-hover:hover {
            background-color: rgba(236, 107, 0);
            /* Ganti dengan warna yang diinginkan */
        }

        .card-animation {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .card-animation:hover {
            transform: translateY(-5px);
        }

        .counter {
            font-size: 2.5rem;
            font-weight: bold;
            color: #05654F;
        }
    </style>
    <style>
        :root {
            --custom-navbar-background-color: #CF6105;
            /* Atur warna latar belakang navbar di sini */
        }

        .navbar {
            background-color: transparent;
            /* Atur transparan atau warna asli di sini */
            transition: background-color 0.3s ease;
            /* Tambahkan transisi jika diinginkan */
        }

        .navbar.navbar-dark {
            background-color: var(--custom-navbar-background-color);
            /* Hanya ubah warna saat navbar-dark */
        }
    </style>
</head>

<body>

    <!-- Navbar -->
    <nav id="navbar" class="navbar navbar-expand-lg navbar-light fixed-top" style="font-size: 18px;">
        <div class="container-fluid text-white">
            <a class="navbar-brand text-white" href="#"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav" style="padding: 10px;">
                <ul class="navbar-nav ">
                    <li class="nav-item" style="margin-right: 20px;">
                        <a class="nav-link active text-white fw-bold" aria-current="page" href="<?php echo base_url('/'); ?>">Beranda</a>
                    </li>
                    <li class="nav-item dropdown" style="margin-right: 10px;">
                        <a class="nav-link dropdown-toggle text-white fw-bold" href="#" id="navbarDropdownRuangBelajar" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Ruang Belajar
                        </a>
                        <ul class="dropdown-menu dropdown-menu-right animate__animated animate__bounceIn" aria-labelledby="navbarDropdownRuangBelajar" style="font-size: 14px; width: 700px;">
                            <div class="row" style="margin: 10px;">
                                <div class="col-12 col-md-4 p-2">
                                    <a href="#" class="card card-hover" style="text-decoration: none; color: inherit;">
                                        <div class="card-body" style="background-image: url('https://cdn.excode.my.id/assets/png_hak2s1_5879.png'); background-size: cover; background-position: center; height: 100px;">
                                            <h6 class="card-title fw-bold">E-PERPUSTAKAAN</h6>
                                            <p class="card-text">Layanan perpustakaan serta berbasis digital</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-12 col-md-4 p-2">
                                    <a href="<?php echo base_url('auth/loginsiswa'); ?>" class="card card-hover" style="text-decoration: none; color: inherit;">
                                        <div class="card-body" style="background-image: url('https://cdn.excode.my.id/assets/png_hak2s1_5879.png'); background-size: cover; background-position: center; height: 100px;">
                                            <h6 class="card-title fw-bold">E-BOOK</h6>
                                            <p class="card-text">Layanan buku belajar siswa elektronik daring</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-12 col-md-4 p-2">
                                    <a href="<?php echo base_url('auth/loginsiswa'); ?>" class="card card-hover" style="text-decoration: none; color: inherit; ">
                                        <div class="card-body" style="background-image: url('https://cdn.excode.my.id/assets/png_hak2s1_5879.png'); background-size: cover; background-position: center; height: 100px;">
                                            <h6 class="card-title fw-bold">E-OSIS</h6>
                                            <p class="card-text">Layanan pemilihan ketua osis berbasis voting</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-12 col-md-4 p-2">
                                    <a href="<?php echo base_url('auth/loginsiswa'); ?>" class="card card-hover" style="text-decoration: none; color: inherit;">
                                        <div class="card-body" style="background-image: url('https://cdn.excode.my.id/assets/png_hak2s1_5879.png'); background-size: cover; background-position: center; height: 100px;">
                                            <h6 class="card-title fw-bold">E-LEARNING</h6>
                                            <p class="card-text">Layanan pembelajaran dan tugas daring</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-12 col-md-4 p-2">
                                    <a href="<?php echo base_url('auth/loginbk'); ?>" class="card card-hover" style="text-decoration: none; color: inherit;">
                                        <div class="card-body" style="background-image: url('https://cdn.excode.my.id/assets/png_hak2s1_5879.png'); background-size: cover; background-position: center; height: 100px;">
                                            <h6 class="card-title fw-bold">E-POIN</h6>
                                            <p class="card-text">Layanan pencatatan pelanggaran poin siswa</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-12 col-md-4 p-2">
                                    <a href="#" class="card card-hover" style="text-decoration: none; color: inherit;">
                                        <div class="card-body" style="background-image: url('https://cdn.excode.my.id/assets/png_hak2s1_5879.png'); background-size: cover; background-position: center; height: 100px;">
                                            <h6 class="card-title fw-bold">E-KELULUSAN</h6>
                                            <p class="card-text">Layanan pengumuman kelulusan siswa</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </ul>
                    </li>

                    <li class="nav-item dropdown" style="margin-right: 10px;">
                        <a class="nav-link dropdown-toggle text-white fw-bold" href="#" id="navbarDropdownManajemen" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Manajemen
                        </a>
                        <ul class="dropdown-menu dropdown-menu-right animate__animated animate__bounceIn" aria-labelledby="navbarDropdownManajemen" style="font-size: 14px; width: 400px;">
                            <div class="row" style="margin: 5px;">
                                <div class="col-12 col-md-6 p-2">
                                    <a href="<?php echo base_url() ?>Auth/loginptk" class="card card-hover" style="text-decoration: none; color: inherit;">
                                        <div class="card-body" style="background-image: url('https://cdn.excode.my.id/assets/superLMSBAONSidebarBackgrond.png'); background-size: cover; background-position: center; height: 100px;">
                                            <h6 class="card-title fw-bold"> GURU</h6>
                                            <p class="card-text">Portal manajemen PTK dan STAFF</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-12 col-md-6 p-2">
                                    <a href="<?php echo base_url() ?>Auth/loginbendahara" class="card card-hover" style="text-decoration: none; color: inherit;">
                                        <div class="card-body" style="background-image: url('https://cdn.excode.my.id/assets/superLMSBAONSidebarBackgrond.png'); background-size: cover; background-position: center; height: 100px;">
                                            <h6 class="card-title fw-bold"> BENDAHARA</h6>
                                            <p class="card-text">Portal manajemen BENDAHARA</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-12 col-md-6 p-2">
                                    <a href="<?php echo base_url() ?>Auth/loginbk" class="card card-hover" style="text-decoration: none; color: inherit;">
                                        <div class="card-body" style="background-image: url('https://cdn.excode.my.id/assets/superLMSBAONSidebarBackgrond.png'); background-size: cover; background-position: center; height: 100px;">
                                            <h6 class="card-title fw-bold"> BK</h6>
                                            <p class="card-text">Portal manajemen Bimbingan Konseling</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-12 col-md-6 p-2">
                                    <a href="<?php echo base_url() ?>Auth/loginadmin" class="card card-hover" style="text-decoration: none; color: inherit;">
                                        <div class="card-body" style="background-image: url('https://cdn.excode.my.id/assets/superLMSBAONSidebarBackgrond.png'); background-size: cover; background-position: center; height: 100px;">
                                            <h6 class="card-title fw-bold"> OPERATOR</h6>
                                            <p class="card-text">Portal manajemen OPERATOR & ADMIN</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </ul>
                    </li>
                    <?php foreach ($portalppdb as $menuppdb) : ?>
                        <?php if ($menuppdb->status_ppdb == 1) : ?>
                            <li class="nav-item" style="margin-right: 20px;">
                                <a class="nav-link active text-white fw-bold" aria-current="page" href="<?php echo base_url('landing/portalppdb'); ?>"> PPDB</a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                    <?php foreach ($portalkelulusan as $status) : ?>
                        <?php if ($status->status_pengumuman == 1) : ?>
                            <li class="nav-item" style="margin-right: 20px;">
                                <a class="nav-link active text-white fw-bold" aria-current="page" href="<?php echo base_url('landing/portalkelulusan'); ?>"> Kelulusan</a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- End Navbar -->


    <header class="hero">
        <div class="container d-grid gap-3">
            <div class="row align-items-center">
                <div class="col-md-2 text-center">
                    <img src="<?php echo htmlspecialchars(base_url('assets/web/' . $res->logo), ENT_QUOTES, 'UTF-8'); ?>" alt="Gambar" class="img-fluid" style="width: 150px; height: auto;"> <!-- Ganti dengan URL gambar Anda -->
                </div>
                <div class="col-md-6 text-center text-lg-start">
                    <h1 class="glow"><?php echo htmlspecialchars($res->nama_lembaga, ENT_QUOTES, 'UTF-8'); ?></h1>
                    <p class="lead">Layanan Manajemen Sekolah Berbasis Digital <br><span class="fw-bold">SMARTSCHOOL </span> &nbsp;<span class="badge text-bg-success">Version <?php echo htmlspecialchars($version->current_version, ENT_QUOTES, 'UTF-8'); ?></span></p>
                </div>
                <div class="col-md-4">
                    <div class="card shadow-sm">
                        <div class="card-body p-5">
                            <h4 class="card-title text-center mb-4">Login Smartschool Siswa</h4>

                            <form action="auth/loginsiswa" method="POST">
                                <div class="form-group mb-3">
                                    <label for="username" class="form-label">Username</label>
                                    <input type="text" class="form-control" id="username" name="username" placeholder="Username" required>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="password" class="form-label">Password</label>
                                    <div class="input-group">
                                        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                                        <button class="btn btn-outline-secondary toggle-password" type="button">
                                            <i class="fa fa-eye"></i>
                                        </button>
                                    </div>
                                </div>

                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-success btn-lg">Login</button>
                                </div>
                            </form>
                            <div>
                                <!-- Tampilkan pesan flashdata -->
                                <?php if ($this->session->flashdata('message_login_error')) : ?>
                                    <div class="badge bg-danger badge-dismissible fade show small-badge m-0">
                                        <?= $this->session->flashdata('message_login_error'); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="card-footer text-white text-center bg-secondary py-3">
                            Belum punya akun? <bold>Hubungi Bagian ICT</bold>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>




    <section class="py-5 text-center">
        <div class="container mt-5">
            <div class="row text-center">
                <div class="col-md-3">
                    <div class="card-animation p-4" style="background-image: url('https://cdn.excode.my.id/assets/landing/card-bg.png'); background-size: cover; background-position: center;">
                        <h5>Jumlah Siswa</h5>
                        <p class="counter" data-count="<?php echo $total_siswa; ?>">0 </p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card-animation p-4" style="background-image: url('https://cdn.excode.my.id/assets/landing/card-bg.png'); background-size: cover; background-position: center;">
                        <h5>Jumlah Guru</h5>
                        <p class="counter" data-count="<?php echo $total_guru; ?>">0</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card-animation p-4" style="background-image: url('https://cdn.excode.my.id/assets/landing/card-bg.png'); background-size: cover; background-position: center;">
                        <h5>Jumlah kelas</h5>
                        <p class="counter" data-count="<?php echo $total_kelas; ?>">0</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card-animation p-4" style="background-image: url('https://cdn.excode.my.id/assets/landing/card-bg.png'); background-size: cover; background-position: center;">
                        <h5>Jumlah Alumni</h5>
                        <p class="counter" data-count="<?php echo $total_alumni; ?>">0</p>
                    </div>
                </div>
            </div>
        </div>
    </section>






    <section class="py-5">
        <div class="container">
            <h2 class="text-center">Pengumuman Dan Informasi</h2>
            <div class="row">
                <div class="col-md-12">
                    <div class="card-animation border-0">
                        <div class="card-body hero-textsedang">
                            <div class="container">
                                <div class="row justify-content">
                                    <div class="row">
                                        <?php $counter = 0; ?>
                                        <?php foreach ($berita as $kartu) : ?>
                                            <?php if ($counter < 4) : ?>
                                                <div class="col-md-3 mb-3" style="padding: 10px;">
                                                    <div class="card" style="height: 100%; display: flex; flex-direction: column; justify-content: space-between;">
                                                        <img src="<?php echo base_url() ?>upload/berita/<?php echo htmlspecialchars($kartu->gambar_berita, ENT_QUOTES, 'UTF-8'); ?>" class="card-img-top" alt="#" style="width: 100%; height: 200px; object-fit: cover; transition: transform 0.3s;">
                                                        <div class="card-body text-left" style="padding: 10px; flex-grow: 1;">
                                                            <span style="font-size: 15px;"><?php echo date('d-m-Y H:i:s', strtotime($kartu->tanggal_berita)); ?></span>
                                                            <h5 class="card-title" style="font-size: 22px;"><?php echo htmlspecialchars($kartu->judul_berita, ENT_QUOTES, 'UTF-8'); ?></h5>
                                                            <p>
                                                                <?php
                                                                $max_chars = 250; // Batas karakter yang ingin ditampilkan
                                                                $isi_berita = $kartu->isi_berita;
                                                                // Decode HTML entities jika perlu
                                                                $isi_berita = htmlspecialchars_decode($isi_berita);
                                                                // Potong teks jika lebih dari batas karakter
                                                                $isi_berita_display = (strlen($isi_berita) > $max_chars) ? substr($isi_berita, 0, $max_chars) . '...' : $isi_berita;
                                                                ?>
                                                                <!-- Tampilkan isi berita di dalam tag HTML -->
                                                            <div class="content" style="font-size: 15px; color: #7A7A7A;">
                                                                <?php echo $isi_berita_display; ?>
                                                            </div>
                                                            </p>
                                                        </div>
                                                        <div class="card-footer text-center" style="background-color: #ffffff;">
                                                            <a href="#" class="btn btn-outline-danger btn-lg lihat-detail-btn" data-bs-toggle="modal" data-bs-target="#detailModal" data-judul="<?php echo htmlspecialchars($kartu->judul_berita, ENT_QUOTES, 'UTF-8'); ?>" data-isi="<?php echo htmlspecialchars($isi_berita, ENT_QUOTES, 'UTF-8'); ?>" style="border-radius: 30px; font-size: 18px; color:dark;">Lihat Detail</a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php $counter++; ?>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                        <!-- Modal -->
                                        <div class="modal fade" id="detailModal" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="detailModalLabel" style="color: #000;">Detail Berita</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body" style="color: #000; font-size: 18px;">
                                                        <h5 id="modalJudul" style="color: #000; font-size: 24px;"></h5>
                                                        <p id="modalIsi" style="color: #000;"></p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div id="carouselExample" class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000"> <!-- 5000 ms = 5 detik -->
                    <div class="carousel-inner">
                        <?php for ($i = 0; $i < count($dataguru); $i += 6) : ?>
                            <div class="carousel-item <?= $i === 0 ? 'active' : '' ?>">
                                <div class="row">
                                    <?php for ($j = $i; $j < $i + 6; $j++) : ?>
                                        <?php if ($j < count($dataguru)) : ?>
                                            <div class="col-md-2">
                                                <img src="<?= base_url('assets/ptk/profile/' . $dataguru[$j]->avatar) ?>" class="d-block w-100 carousel-img" alt="Avatar Guru <?= $j + 1 ?>">
                                            </div>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                </div>
                            </div>
                        <?php endfor; ?>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
        </div>
    </div>


    <footer class="text-center py-4">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> <?php echo htmlspecialchars($res->nama_lembaga, ENT_QUOTES, 'UTF-8'); ?>. Semua Hak Dilindungi.</p>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        $(document).ready(function() {
            $('.counter').each(function() {
                $(this).prop('Counter', 0).animate({
                    Counter: $(this).data('count')
                }, {
                    duration: 2000, // Durasi animasi dalam milidetik
                    easing: 'swing', // Tipe easing
                    step: function(now) {
                        $(this).text(Math.ceil(now)); // Pembulatan angka
                    }
                });
            });
        });
    </script>


    <script>
        //Modal Form
        document.addEventListener('DOMContentLoaded', (event) => {
            const detailButtons = document.querySelectorAll('.lihat-detail-btn');
            detailButtons.forEach(button => {
                button.addEventListener('click', (event) => {
                    const judul = button.getAttribute('data-judul');
                    const isi = button.getAttribute('data-isi');
                    document.getElementById('modalJudul').textContent = judul;
                    document.getElementById('modalIsi').innerHTML = isi;
                });
            });
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const navbar = document.getElementById('navbar');
            let scrolled = false; // Tambahkan variabel untuk melacak apakah sudah di-scroll atau belum

            // Add scroll event listener to toggle classes and custom color when scrolled
            window.addEventListener('scroll', function() {
                if (window.scrollY > 100 && !scrolled) {
                    navbar.classList.remove('navbar-light');
                    navbar.classList.add('navbar-dark');
                    scrolled = true; // Setelah melakukan scroll pertama kali, atur flag ke true
                } else if (window.scrollY <= 100 && scrolled) {
                    navbar.classList.remove('navbar-dark');
                    navbar.classList.add('navbar-light');
                    scrolled = false; // Setelah kembali ke atas, atur flag kembali ke false
                }
            });
        });
    </script>

    <script>
        const togglePassword = document.querySelector('.toggle-password');
        const password = document.querySelector('#password');

        togglePassword.addEventListener('click', function(e) {
            // toggle icon
            const icon = this.querySelector('i');
            if (password.type === 'password') {
                password.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                password.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    </script>



</body>

</html>