<!DOCTYPE html>
<html lang="en">
<?php foreach ($data_site as $res) { ?> <?php } ?>
<?php foreach ($versi as $version) { ?> <?php } ?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $nama_lembaga = htmlspecialchars($res->nama_lembaga, ENT_QUOTES, 'UTF-8'); ?></title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.excode.my.id/assets/landing/css/mobile.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 90vh;
            margin: 0;
        }


        .menu {
            background-color: #ffffff;
            padding: 10px 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        .menu-items {
            display: flex;
            gap: 20px;
            /* Jarak antar item menu */
        }

        .menu-item {
            position: relative;
        }

        .menu-item a {
            text-decoration: none;
            color: #333;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            display: flex;
            align-items: center;
        }

        .menu-item a .fas {
            margin-left: 5px;
            font-size: 12px;
            color: #000;
            /* Warna hitam untuk ikon */
        }

        .menu-item:hover .dropdown-content {
            display: block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #fff;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            top: 100%;
            left: 0;
            min-width: 160px;
            border-radius: 5px;
        }

        .dropdown-content a {
            color: #333;
            padding: 10px 15px;
            display: block;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .dropdown-content a:hover {
            background-color: #f0f0f0;
        }

        .menu-notif {
            color: #333;
            font-size: 14px;
            margin-right: 10px;
        }





        .container {
            width: 100%;
            max-width: 360px;
            margin: 20px auto;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.2);
            padding: 20px;
            text-align: center;
            background-image: url("https://cdn.excode.my.id/assets/landing/login-mobile.jpg");
            /* Ganti URL dengan URL gambar latar belakang Anda */
            background-size: cover;
            background-position: center;
        }
    </style>
</head>

<body style="background-color: #f0f0f0; background-image: url('https://cdn.excode.my.id/assets/landing/light-blue-wavey-background_78370-519.jpg'); background-size: cover; background-position: center;">
    <div class="menu">
        <div class="menu-items">
            <div class="menu-item">
                <a href="#">Beranda</a>
            </div>
            <div class="menu-item dropdown">
                <a href="#" class="dropdown-toggle">Login <i class="fas fa-chevron-down" style="color: black;"></i></a>
                <div class="dropdown-content">
                    <a href="<?php echo base_url('/auth/loginptk'); ?>">Login Guru</a>
                    <a href="<?php echo base_url('/auth/loginadmin'); ?>">Login Operator</a>
                    <a href="<?php echo base_url('/auth/loginbendahara'); ?>">Login Bendahara</a>
                    <a href="<?php echo base_url('/auth/loginbk'); ?>">Login Bk</a>
                </div>
            </div>
            <?php foreach ($portalppdb as $menuppdb) : ?>
                <?php if ($menuppdb->status_ppdb == 1) : ?>
                    <div class="menu-item">
                        <a href="<?php echo base_url('landing/portalppdb'); ?>"> PPDB</a>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
            <?php foreach ($portalkelulusan as $menuskl) : ?>
                <?php if ($menuskl->status_pengumuman == 1) : ?>
                    <div class="menu-item">
                        <a href="<?php echo base_url('landing/portalkelulusan'); ?>"> Kelulusan</a>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>






        <div class="menu-notif">
            <?php
            if (isset($message_login_error)) {
                echo $message_login_error;
            } elseif ($this->session->flashdata('message_error')) {
                echo $this->session->flashdata('message_error');
            }
            ?>
        </div>
    </div>

    </div>



    <div class="container">
        <div class="header">
            <h1><?php echo $res->nama_lembaga; ?></h1>
            <p>Manajemen Sekolah Berbasis Digital<br>SMARTSCHOOL <span class="badge">Version <?php echo $version->current_version; ?></span></p>
        </div>
        <div class="logo">
            <i class="fas fa-user-circle"></i>
        </div>
        <form action="auth/loginsiswa" method="POST">
            <div class="form-group">
                <label for="username">Email / Username</label>
                <input type="text" id="username" name="username" placeholder="Email atau Username">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Password">
            </div>
            <p class="form-description">Lupa password ? <a href="#">Hubungi Operator</a></p>
            <button type="submit" class="btn-sign-up">Masuk</button>
            <p class="footer-description">Dengan masuk, Anda menyetujui peraturan dan kebijakan privasi</p>
        </form>
    </div>
</body>

</html>