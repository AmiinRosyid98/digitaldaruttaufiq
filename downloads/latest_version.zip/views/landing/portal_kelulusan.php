<!DOCTYPE html>
<html lang="en">
<?php foreach ($data_site as $res) { ?> <?php } ?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $nama_lembaga = htmlspecialchars($res->nama_lembaga, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="alternate icon" type="image/png" href="<?php echo  base_url() ?>assets/web/<?php echo $res->logo; ?>">
    <link rel="stylesheet" href="https://cdn.excode.my.id/assets/web/portalkelulusan.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

</head>

<body>

    <div class="container" id="portal-content">
        <h1>Portal Kelulusan</h1>
        <h5>Masukkan NIS Anda Untuk Melihat Hasil Pengumuman</h5>
        <form id="searchForm">
            <input type="text" id="nis" name="nis" required>
            <button type="submit" id="searchBtn">Cari</button>
        </form>
        <div id="searchResults">
            <!-- Tempat untuk menampilkan hasil pencarian -->
        </div>
    </div>

    <div class="countdown-container" id="countdown-container">
        <div class="countdown" id="countdown">
            <div id="days" class="box"></div>
            <div id="hours" class="box"></div>
            <div id="minutes" class="box"></div>
            <div id="seconds" class="box"></div>
        </div>
    </div>

    <!-- Overlay untuk efek backdrop -->
    <div id="overlay" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); z-index: 999; text-align: center;">
        <div id="loadingIndicator" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white;">
            <i class="fas fa-spinner fa-spin" style="font-size: 24px;"></i>
            <p>Mendapatkan Data...</p>
        </div>
    </div>

    <div id="searchResults" style="position: relative; min-height: 100px;"></div>


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(document).ready(function() {
        $('#searchForm').submit(function(event) {
            event.preventDefault(); // Menghentikan pengiriman form default

            var nis = $('#nis').val(); // Ambil nilai NIS dari input

            // Menampilkan overlay dan loading indicator
            $('#overlay').show();
            $('#searchResults').html(''); // Kosongkan hasil sebelumnya

            // Simulasi delay 5 detik sebelum melakukan AJAX
            setTimeout(function() {
                $.ajax({
                    type: 'POST',
                    url: '<?php echo base_url('landing/cari_siswa'); ?>', 
                    data: {
                        nis: nis
                    },
                    dataType: 'json',
                    success: function(response) {
                        $('#overlay').hide(); // Sembunyikan overlay

                        if (response.length > 0) {
                            var html = '<table class="table">';
                            html += '<thead><tr><th style="text-align: center;">Nama Siswa</th><th style="text-align: center;">NIS</th><th style="text-align: center;">STATUS</th></tr></thead>';
                            html += '<tbody>';

                            $.each(response, function(index, siswa) {
                                var statusText;
                                switch (siswa.status_kelulusan) {
                                    case '0':
                                        statusText = 'Aktif';
                                        break;
                                    case '1':
                                        statusText = 'Lulus';
                                        break;
                                    case '2':
                                        statusText = 'Tidak Lulus';
                                        break;
                                    default:
                                        statusText = 'Belum Diketahui';
                                }

                                html += '<tr>';
                                html += '<td style="text-align: center;">' + siswa.nama_siswa + '</td>';
                                html += '<td style="text-align: center;">' + siswa.nis + '</td>';
                                html += '<td style="text-align: center;">' + statusText + '</td>';
                                html += '</tr>';
                            });

                            html += '</tbody></table>';
                            $('#searchResults').html(html);
                        } else {
                            $('#searchResults').html('<p class="message">Tidak ada data ditemukan berdasarkan NIS yang dimasukkan.</p>');
                        }
                    },
                    error: function() {
                        $('#overlay').hide(); // Sembunyikan overlay
                        $('#searchResults').html('<p class="message">Terjadi kesalahan. Silakan coba lagi nanti.</p>');
                    }
                });
            }, 3000); // Delay selama 3000 ms (3 detik)
        });
    });
</script>



    <script>
        // Tanggal target untuk countdown (dari PHP)
        var targetDate = <?php echo $target_time; ?>;

        // Memeriksa apakah countdown sudah berakhir saat halaman dimuat
        var now = new Date().getTime();
        var distance = targetDate - now;

        if (distance < 0) {
            // Countdown sudah berakhir, tampilkan konten portal
            document.getElementById('countdown-container').style.display = 'none'; // Sembunyikan countdown container
            document.querySelector('.container').style.display = 'block'; // Tampilkan konten portal
        } else {
            // Countdown masih berjalan, tampilkan countdown dan sembunyikan form
            document.getElementById('countdown-container').style.display = 'block'; // Tampilkan countdown container
            document.querySelector('.container').style.display = 'none'; // Sembunyikan konten portal
            document.querySelector('form').style.display = 'none'; // Sembunyikan form pencarian
        }

        // Memperbarui countdown setiap detik
        var countdown = setInterval(function() {
            var now = new Date().getTime();
            var distance = targetDate - now;

            // Perhitungan waktu untuk hari, jam, menit, dan detik
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);

            // Format angka satu digit dengan 0 di depan (misalnya: 08)
            hours = ('0' + hours).slice(-2);
            minutes = ('0' + minutes).slice(-2);
            seconds = ('0' + seconds).slice(-2);

            // Menampilkan hasil countdown dalam elemen dengan id 'countdown'
            document.getElementById('days').innerHTML = `
                <div>${days}</div>
                <span>Hari</span>
            `;
            document.getElementById('hours').innerHTML = `
                <div>${hours}</div>
                <span>Jam</span>
            `;
            document.getElementById('minutes').innerHTML = `
                <div>${minutes}</div>
                <span>Menit</span>
            `;
            document.getElementById('seconds').innerHTML = `
                <div>${seconds}</div>
                <span>Detik</span>
            `;

            // Jika waktu mundur selesai, arahkan ke halaman portal kelulusan
            if (distance < 0) {
                clearInterval(countdown);
                document.getElementById('countdown-container').style.display = 'none'; // Sembunyikan countdown container
                document.body.style.backgroundColor = '#f0f0f0'; // Ubah warna latar belakang kembali
                document.querySelector('.container').style.display = 'block'; // Tampilkan konten portal
            } else {
                document.getElementById('countdown-container').style.display = 'block'; // Tampilkan countdown container
                document.querySelector('.container').style.display = 'none'; // Sembunyikan konten portal
            }
        }, 1000);
    </script>

</body>

</html>