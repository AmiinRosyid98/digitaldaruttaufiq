<!DOCTYPE html>
<html lang="id">
<?php foreach ($data_site as $res) { ?> <?php } ?>
<?php foreach ($ppdb as $settingppdb) { ?> <?php } ?>


<head>

    <meta charSet="utf-8" />
    <meta name="viewport" content="width=device-width" />
    <title>PPDB <?php echo $res->nama_lembaga; ?></title>
    <meta name="robots" content="follow, index" />
    <meta content="Situs resmi Penerimaan Peserta Didik Baru (PPDB) <?php echo $res->nama_lembaga; ?>" name="description" />
    <meta property="og:url" content="https://ppdbjatim.net/" />
    <link rel="canonical" href="https://ppdbjatim.net/" />
    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="PPDB <?php echo $res->nama_lembaga; ?>" />
    <meta property="og:description" content="Situs resmi Penerimaan Peserta Didik Baru (PPDB) <?php echo $res->nama_lembaga; ?>" />
    <meta property="og:title" content="PPDB <?php echo $res->nama_lembaga; ?>" />
    <meta name="image" property="og:image" content="https://og.ppdbdemo.net/api/general?siteName=PPDB%20Jawa%20Timur%202024&amp;description=Situs%20resmi%20Penerimaan%20Peserta%20Didik%20Baru%20(PPDB)%20SMA%2FSMK%20Negeri%20Jawa%20Timur%20Tahun%20Pelajaran%202024%2F2025&amp;logo=https%3A%2F%2Fppdbjatim.net%2Fimages%2Flogo.png&amp;theme=light" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="PPDB <?php echo $res->nama_lembaga; ?>" />
    <meta name="twitter:description" content="Situs resmi Penerimaan Peserta Didik Baru (PPDB) <?php echo $res->nama_lembaga; ?>" />
    <meta name="twitter:image" content="https://og.ppdbdemo.net/api/general?siteName=PPDB%20Jawa%20Timur%202024&amp;description=Situs%20resmi%20Penerimaan%20Peserta%20Didik%20Baru%20(PPDB)%20SMA%2FSMK%20Negeri%20Jawa%20Timur%20Tahun%20Pelajaran%202024%2F2025&amp;logo=https%3A%2F%2Fppdbjatim.net%2Fimages%2Flogo.png&amp;theme=light" />
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo base_url() ?>assets/web/<?php echo $res->logo; ?>" />
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo base_url() ?>assets/web/<?php echo $res->logo; ?>" />
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url() ?>assets/web/<?php echo $res->logo; ?>" />
    <link rel="manifest" href="/favicon/manifest.json" />
    <link rel="mask-icon" href="/favicon/safari-pinned-tab.svg" color="#00e887" />
    <link rel="shortcut icon" href="/favicon/favicon.ico" />
    <meta name="msapplication-TileColor" content="#ffffff" />
    <meta name="msapplication-config" content="/favicon/browserconfig.xml" />
    <meta name="theme-color" content="#ffffff" />
    <meta name="next-head-count" content="25" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/alpinejs/3.2.0/cdn.min.js" defer></script>
    <link rel="preload" href="/_next/static/media/c9a5bc6a7c948fb0-s.p.woff2" as="font" type="font/woff2" crossorigin="anonymous" data-next-font="size-adjust" />
    <link rel="preload" href="/_next/static/media/3c2bf789bf4636a1-s.p.woff2" as="font" type="font/woff2" crossorigin="anonymous" data-next-font="size-adjust" />
    <link rel="preload" href="/_next/static/media/65c2045c60282517-s.p.woff2" as="font" type="font/woff2" crossorigin="anonymous" data-next-font="size-adjust" />
    <link rel="preload" href="/_next/static/media/14006a9027dabdda-s.p.woff2" as="font" type="font/woff2" crossorigin="anonymous" data-next-font="size-adjust" />
    <link rel="preload" href="/_next/static/media/a484622ad89da153-s.p.woff2" as="font" type="font/woff2" crossorigin="anonymous" data-next-font="size-adjust" />
    <link rel="preload" href="/_next/static/media/1806d66cd0183215-s.p.woff2" as="font" type="font/woff2" crossorigin="anonymous" data-next-font="size-adjust" />
    <link rel="preload" href="/_next/static/media/d83041e8e87e7d3f-s.p.woff2" as="font" type="font/woff2" crossorigin="anonymous" data-next-font="size-adjust" />
    <link rel="preload" href="https://cdn.excode.my.id/assets/landing/ppdb/c14942a7c2aa68fb.css" as="style" />
    <link rel="stylesheet" href="https://cdn.excode.my.id/assets/landing/ppdb/c14942a7c2aa68fb.css" data-n-g />
    <link rel="preload" href="https://cdn.excode.my.id/assets/landing/ppdb/de18321657a21c0f.css" as="style" />
    <link rel="stylesheet" href="https://cdn.excode.my.id/assets/landing/ppdb/de18321657a21c0f.css" data-n-p /><noscript data-n-css></noscript>
    <script defer nomodule src="https://cdn.excode.my.id/assets/landing/ppdb/78c92fac7aa8fdd8.js" type="f3e77268fe13094b7f956059-text/javascript"></script>
    <script src="https://cdn.excode.my.id/assets/landing/ppdb/63ed9f2838a02eb3.js" defer type="f3e77268fe13094b7f956059-text/javascript"></script>
    <script src="https://cdn.excode.my.id/assets/landing/ppdb/f8946d4faf8ecd45.js" defer type="f3e77268fe13094b7f956059-text/javascript"></script>
    <script src="https://cdn.excode.my.id/assets/landing/ppdb/main-2dea97e5fdb6e094.js" defer type="f3e77268fe13094b7f956059-text/javascript"></script>
    <script src="https://cdn.excode.my.id/assets/landing/ppdb/_app-cd519faa7b5de558.js" defer type="f3e77268fe13094b7f956059-text/javascript"></script>
    <script src="https://cdn.excode.my.id/assets/landing/ppdb/58cde132-5b3c4e9704be3e71.js" defer type="f3e77268fe13094b7f956059-text/javascript"></script>
    <script src="https://cdn.excode.my.id/assets/landing/ppdb/2208-fc57a98bb574f16f.js" defer type="f3e77268fe13094b7f956059-text/javascript"></script>
    <script src="https://cdn.excode.my.id/assets/landing/ppdb/8246-cef76626f48abac6.js" defer type="f3e77268fe13094b7f956059-text/javascript"></script>
    <script src="https://cdn.excode.my.id/assets/landing/ppdb/5695-2bc5d5be114a6543.js" defer type="f3e77268fe13094b7f956059-text/javascript"></script>
    <script src="https://cdn.excode.my.id/assets/landing/ppdb/1534-602cc9e9e99cda59.js" defer type="f3e77268fe13094b7f956059-text/javascript"></script>
    <script src="https://cdn.excode.my.id/assets/landing/ppdb/index-18805bbadc9d463a.js" type="f3e77268fe13094b7f956059-text/javascript"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        /* CSS untuk menampilkan dropdown saat dihover pada desktop dan tombol toggle pada mobile */
        .dropdown-container {
            position: relative;
        }

        .dropdown-toggle {
            background-color: #ffffff;
            padding: 10px 15px;
            cursor: pointer;
        }

        .dropdown-toggle::after {
            content: '';
            border: solid #333333;
            border-width: 0 4px 4px 0;
            display: inline-block;
            padding: 4px;
            margin-left: 7px;
            transform: rotate(45deg);
        }

        .dropdown-menu {
            display: none;
            position: absolute;
            background-color: #ffffff;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
            padding: 10px 0;
            list-style-type: none;
            margin: 0;
            border-radius: 5px;
            width: 100%;
            /* Sesuaikan lebar dropdown dengan tombol */
            max-width: 500px;
            /* Lebar maksimum dropdown jika diperlukan */
            font-weight: bold;
            /* Teks menjadi tebal */

        }

        .dropdown-menu a {
            display: block;
            padding: 10px 10px;
            text-decoration: none;
            color: #333333;
            transition: background-color 0.3s ease;
        }

        .dropdown-menu a:hover {
            background-color: #f0f0f0;
            border-radius: 30px;
            /* Sudut melengkung pada latar belakang saat dihover */
        }

        .dropdown-menu.hidden {
            display: none;
        }

        .dropdown-menu li {
            padding: 5px 0px;
        }

        .dropdown-menu li a {
            text-decoration: none;
            color: #333333;
            display: block;
        }

        .dropdown-menu {
            display: none;
        }

        /* Menampilkan dropdown saat menu dihover */
        #dropdown-menu-information {
            display: none;
        }

        .dropdown-container:hover [data-dropdown]:hover+.dropdown-menu,
        #dropdown-toggle-desktop:focus+#dropdown-menu-information,
        #dropdown-menu-information:hover {
            display: block;
        }

        /* Media queries untuk tampilan mobile */
        @media (max-width: 768px) {
            .dropdown-toggle {
                width: 100%;
                /* Lebar penuh untuk tombol toggle */
            }
        }
    </style>
</head>

<body>
    <div id="__next">
        <div class="__variable_aaf875 __variable_19d47e">
            <div>
                <div style="position:fixed;z-index:9999;top:16px;left:16px;right:16px;bottom:16px;pointer-events:none"></div>
            </div>
            <div>
                <header class="sticky top-0 z-50 bg-white shadow-sm">
                    <div class="layout flex h-16 items-center gap-12"><a class="py-4 flex items-center gap-2 shrink-0" title="Ke Beranda" href="/"><span class="sr-only">PPDB <?php echo $res->nama_lembaga; ?></span>
                            <figure class="w-9 md:w-10"><img alt="Logo Pemerintah Provinsi Jawa TImur" loading="lazy" width="824" height="900" decoding="async" data-nimg="1" class style="color:transparent" src="<?php echo base_url() ?>assets/web/<?php echo $res->logo; ?>" /></figure>
                            <div class="rounded-full bg-primary-500 px-3 py-[2px]"><span class="font-averta font-semibold text-sm text-white md:text-base"><?php echo $res->nama_lembaga; ?></span></div>
                        </a>
                        <nav class="w-full">
                            <div class="dropdown-container">
                                <nav aria-label="Main" data-orientation="horizontal" dir="ltr" class="relative z-10 hidden flex-1 items-center justify-between space-x-4 xl:flex">
                                    <div style="position:relative">
                                        <!-- Tombol dropdown untuk menu "Information" -->
                                        <button id="dropdown-toggle-desktop" class="dropdown-toggle text-sm text-typo font-averta font-semibold text-left 2xl:text-base" aria-haspopup="true" aria-expanded="false" aria-controls="dropdown-menu-desktop" data-dropdown>
                                            Information
                                        </button>
                                        <!-- Menu dropdown untuk "Information" -->
                                        <ul id="dropdown-menu-information" class="dropdown-menu hidden absolute bg-white shadow-lg rounded mt-2 w-40">
                                            <li><a href="#">Ketentuan</a></li>
                                            <li><a href="#">Prosedur</a></li>
                                            <li><a href="#">Jadwal</a></li>
                                            <li><a href="#">Pagu</a></li>
                                        </ul>
                                        <!-- Menu kedua 
                                        <a href="#" class="text-sm text-typo font-averta font-semibold text-left 2xl:text-base ml-4">Menu 2</a>

                                       
                                        <a href="#" class="text-sm text-typo font-averta font-semibold text-left 2xl:text-base ml-4">Menu 3</a>  Menu ketiga -->
                                    </div>
                                </nav>
                                <div class="flex w-full justify-end xl:hidden">
                                    <!-- Tombol "Toggle Dropdown" untuk mobile -->
                                    <button id="dropdown-toggle-desktop" class="dropdown-toggle text-sm text-typo font-averta font-semibold text-left 2xl:text-base" aria-haspopup="dialog" aria-expanded="false" aria-controls="dropdown-menu">
                                        Information
                                    </button>
                                    <!-- Menu dropdown untuk "Information" -->
                                    <ul id="dropdown-menu-information" class="dropdown-menu hidden absolute bg-white shadow-lg rounded mt-2 w-40">
                                        <li><a href="#">Ketentuan</a></li>
                                        <li><a href="#">Prosedur</a></li>
                                        <li><a href="#">Jadwal</a></li>
                                        <li><a href="#">Pagu</a></li>
                                    </ul>
                                </div>
                            </div>
                            <script>
                                const toggleButton = document.getElementById('dropdown-toggle');
                                const dropdownMenu = document.getElementById('dropdown-menu');

                                toggleButton.addEventListener('mouseover', function() {
                                    dropdownMenu.classList.remove('hidden');
                                });

                                toggleButton.addEventListener('mouseleave', function() {
                                    dropdownMenu.classList.add('hidden');
                                });
                            </script>


                        </nav>
                    </div>
                </header>
                <section class="py-20 md:py-0 relative flex overflow-hidden bg-white bg-cover bg-no-repeat min-h-[calc(100vh-64px)]" style="background-image:url(<?php echo base_url() ?>assets/landing/ppdb/img/particle.svg);box-shadow:inset 0px -4px 20px rgba(153, 156, 160, 0.12)">
                    <div class="layout flex flex-col-reverse justify-between gap-8 md:flex-row">
                        <div class="flex w-full flex-col justify-center md:w-[calc(100%/7*5)]">
                            <div class="space-y-3">
                                <h2 class="font-averta text-xl text-typo font-normal">Selamat datang di</h2>
                                <h1 class="font-averta text-4xl text-typo font-semibold md:text-5xl">Portal Penerimaan Peserta Didik Baru (PPDB) <?php echo $settingppdb->tahun_ppdb; ?></h1>
                                <h2 class="font-averta text-xl text-typo font-normal"><?php echo $res->nama_lembaga; ?></h2>
                            </div>
                            <div class="mt-6 flex flex-wrap gap-2">

                                <!-- Tombol untuk membuka modal -->
                                <div x-data="{ open: false, step: 1 }">
                                    <a class="inline-flex items-center justify-center rounded-lg focus:outline-none focus-visible:ring shadow-sm transition-colors duration-75 min-h-[3rem] px-3.5 md:min-h-[2.75rem] text-base bg-primary-500 text-white border border-primary-600 hover:bg-primary-600 hover:text-white active:bg-primary-700 disabled:bg-primary-700 focus-visible:ring-primary-400 disabled:cursor-not-allowed font-averta font-medium" href="#" @click.prevent="open = true">
                                        <div class="mr-3">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-clipboard-list text-base">
                                                <rect width="8" height="4" x="8" y="2" rx="1" ry="1"></rect>
                                                <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path>
                                                <path d="M12 11h4"></path>
                                                <path d="M12 16h4"></path>
                                                <path d="M8 11h.01"></path>
                                                <path d="M8 16h.01"></path>
                                            </svg>
                                        </div>
                                        PENDAFTARAN
                                    </a>

                                    <!-- Modal -->
                                    <div x-show="open" class="fixed inset-0 flex items-center justify-center z-50">
                                        <div class="fixed inset-0 bg-black opacity-50" @click="open = false; step = 1"></div>
                                        <div class="bg-white p-6 rounded-lg shadow-lg z-50 max-w-6xl mx-auto w-full">
                                            <h2 class="text-xl font-bold mb-4">Pendaftaran</h2>

                                            <!-- Indikator Langkah -->
                                            <div class="flex justify-center items-center space-x-4 mb-4">
                                                <template x-for="i in 5">
                                                    <div class="flex items-center">
                                                        <!-- Lingkaran Indikator -->
                                                        <div :class="{'bg-blue-500 text-white': step >= i}" class="rounded-full border-2 border-blue-500 w-10 h-10 flex items-center justify-center">
                                                            <span x-text="i"></span>
                                                        </div>
                                                        <!-- Keterangan Langkah -->
                                                        <div class="ml-2 text-center">
                                                            <div class="text-xs font-medium">
                                                                Step <span x-text="i"></span>
                                                            </div>
                                                            <div x-show="i === 1" class="text-sm mt-1">
                                                                Data Diri
                                                            </div>
                                                            <div x-show="i === 2" class="text-sm mt-1">
                                                                Pilihan Jalur
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Garis Penghubung (kecuali di langkah terakhir) -->
                                                    <template x-if="i !== 5">
                                                        <div class="h-0.5 bg-blue-500 my-2" style="width: 6rem;"></div>
                                                    </template>
                                                </template>
                                            </div>




                                            <div x-data="{
    step: 1,
    nama_pendaftar: '',
    nik: '',
    kk: '',
    tempat_lahir: '',
    tanggal_lahir: '',
    no_hp: '',
    jenis_kelamin: '',
    alamat_siswa: '',
    rt: '',
    rw: '',
    no_skhu: '',
    asal_sekolah: '',
    jalur: '',
    nama_orang_tua: '',
    no_telp_orang_tua: '',
    kode_pin: '', // Tambah properti kode_pin
    setuju: false, // Tambah properti setuju

    validationErrors: {
        step1: {
            kode_pin: false,
            nama_pendaftar: false,
            nik: false,
            kk: false,
            tempat_lahir: false,
            tanggal_lahir: false,
            no_hp: false,
            jenis_kelamin: false,
            alamat_siswa: false,
            rt: false,
            rw: false
        },
        step2: {
            no_skhu: false,
            asal_sekolah: false,
            jalur: false
        },
        step3: {
            nama_orang_tua: false,
            no_telp_orang_tua: false
        }
    },
    validateStep1() {
        let valid = true;
        if (this.kode_pin === '') {
            this.validationErrors.step1.kode_pin = true;
            valid = false;
        } else {
            this.validationErrors.step1.nama_pendaftar = false;
        }
        if (this.nama_pendaftar === '') {
            this.validationErrors.step1.nama_pendaftar = true;
            valid = false;
        } else {
            this.validationErrors.step1.nama_pendaftar = false;
        }
        if (this.kk === '') {
            this.validationErrors.step1.kk = true;
            valid = false;
        } else {
            this.validationErrors.step1.kk = false;
        }
        if (this.nik === '') {
            this.validationErrors.step1.nik = true;
            valid = false;
        } else {
            this.validationErrors.step1.nik = false;
        }
        if (this.tempat_lahir === '') {
            this.validationErrors.step1.tempat_lahir = true;
            valid = false;
        } else {
            this.validationErrors.step1.tempat_lahir = false;
        }
        if (this.tanggal_lahir === '') {
            this.validationErrors.step1.tanggal_lahir = true;
            valid = false;
        } else {
            this.validationErrors.step1.tanggal_lahir = false;
        }
        if (this.no_hp === '') {
            this.validationErrors.step1.no_hp = true;
            valid = false;
        } else {
            this.validationErrors.step1.no_hp = false;
        }
        if (this.jenis_kelamin === '') {
            this.validationErrors.step1.jenis_kelamin = true;
            valid = false;
        } else {
            this.validationErrors.step1.jenis_kelamin = false;
        }

        // Validasi tambahan untuk alamat_siswa, rt, dan rw
        if (this.alamat_siswa === '') {
            this.validationErrors.step1.alamat_siswa = true;
            valid = false;
        } else {
            this.validationErrors.step1.alamat_siswa = false;
        }
        if (this.rt === '') {
            this.validationErrors.step1.rt = true;
            valid = false;
        } else {
            this.validationErrors.step1.rt = false;
        }
        if (this.rw === '') {
            this.validationErrors.step1.rw = true;
            valid = false;
        } else {
            this.validationErrors.step1.rw = false;
        }
        
        return valid;
    },
    validateStep2() {
        let valid = true;
        if (this.no_skhu === '') {
            this.validationErrors.step2.no_skhu = true;
            valid = false;
        } else {
            this.validationErrors.step2.no_skhu = false;
        }
        if (this.asal_sekolah === '') {
            this.validationErrors.step2.asal_sekolah = true;
            valid = false;
        } else {
            this.validationErrors.step2.asal_sekolah = false;
        }
        if (this.jalur === '') {
            this.validationErrors.step2.jalur = true;
            valid = false;
        } else {
            this.validationErrors.step2.jalur = false;
        } 
        return valid;
    },
    validateStep3() {
        let valid = true;
        if (this.nama_orang_tua === '') {
            this.validationErrors.step3.nama_orang_tua = true;
            valid = false;
        } else {
            this.validationErrors.step3.nama_orang_tua = false;
        }
        if (this.no_telp_orang_tua === '') {
            this.validationErrors.step3.no_telp_orang_tua = true;
            valid = false;
        } else {
            this.validationErrors.step3.no_telp_orang_tua = false;
        }
        return valid;
    },
generatePIN() {
        let pinLength = 6;
        let pin = '';
        for (let i = 0; i < pinLength; i++) {
            pin += Math.floor(Math.random() * 10);
        }
        this.kode_pin = pin;
    },
    init() {
        this.generatePIN(); // Panggil generatePIN() saat komponen diinisialisasi
    },
    simpanData() {
        if (this.validateStep1() && this.validateStep2() && this.validateStep3()) {
            let formData = new FormData();
            formData.append('nama_pendaftar', this.nama_pendaftar);
            formData.append('nik', this.nik);
            formData.append('kk', this.kk);
            formData.append('tempat_lahir', this.tempat_lahir);
            formData.append('tanggal_lahir', this.tanggal_lahir);
            formData.append('no_hp', this.no_hp);
            formData.append('jenis_kelamin', this.jenis_kelamin);
            formData.append('no_skhu', this.no_skhu);
            formData.append('asal_sekolah', this.asal_sekolah);
            formData.append('jalur', this.jalur);
            formData.append('nama_orang_tua', this.nama_orang_tua);
            formData.append('no_telp_orang_tua', this.no_telp_orang_tua);
            formData.append('kode_pin', this.kode_pin); // Sertakan kode_pin dalam FormData
            formData.append('alamat_siswa', this.alamat_siswa); // Sertakan alamat_siswa dalam FormData
            formData.append('rt', this.rt); // Sertakan rt dalam FormData
            formData.append('rw', this.rw); // Sertakan rw dalam FormData


            // Make an AJAX request to submit the form data
            fetch('<?= base_url('landing/simpan_pesertappdb') ?>', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (response.ok) {
                    this.step = 5; // Proceed to step 5 on successful submission
                    this.clearForm(); // Optionally clear form data after successful submission
                    // Optionally show success message
                } else {
                    throw new Error('Gagal menyimpan data.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                // Optionally show error message
            });
        }
    },
    clearForm() {
        // Reset all form fields and states here
        this.nama_pendaftar = '';
        this.nik = '';
        this.kk = '';
        this.tempat_lahir = '';
        this.tanggal_lahir = '';
        this.no_hp = '';
        this.jenis_kelamin = '';
        this.no_skhu = '';
        this.asal_sekolah = '';
        this.jalur = '';
        this.nama_orang_tua = '';
        this.no_telp_orang_tua = '';
        this.kode_pin = ''; // Reset also the kode_pin field
        this.alamat_siswa = ''; // Reset also the alamat_siswa field
        this.rt = ''; // Reset also the rt field
        this.rw = ''; // Reset also the rw field
        // Reset validation errors
        this.validationErrors = {
            step1: {
                kode_pin: false,
                nama_pendaftar: false,
                nik: false,
                kk: false,
                tempat_lahir: false,
                tanggal_lahir: false,
                no_hp: false,
                jenis_kelamin: false,
                alamat_siswa: false, // Tambah properti validationErrors untuk alamat_siswa
                rt: false, // Tambah properti validationErrors untuk rt
                rw: false // Tambah properti validationErrors untuk rw
            },
            step2: {
                no_skhu: false,
                asal_sekolah: false,
                jalur: false
            },
            step3: {
                nama_orang_tua: false,
                no_telp_orang_tua: false
            }
        };
    }
}">


                                                <form method="post" action="<?= base_url('landing/simpan_pesertappdb') ?>">
                                                    <!-- Step 1: Informasi Peserta -->
                                                    <div x-show="step === 1" class="grid grid-cols-2 gap-4" style="grid-template-columns: 1fr 2fr;">
                                                        <!-- Pesan Validasi -->
                                                        <div class="col-span-2 mb-4 text-red-500 text-sm" x-show="!validateStep1()">Silakan lengkapi semua informasi peserta sebelum melanjutkan.</div>

                                                        <!-- Bagian Kiri (Card Catatan) -->
                                                        <div class="bg-gray-100 p-4 rounded-lg">
                                                            <h3 class="text-lg font-bold mb-2">Catatan:</h3>
                                                            <p class="text-sm" style="color: red; font-weight: bold;">Catat Dan simpan Kode Pin anda !</p>
                                                            <p><br></p>
                                                            <p class="text-sm">Harap diketahui bahwa Kode PIN akan berubah setiap anda merefresh halaman,Bila Kode PIN (Kode Pendaftaran tidak muncul secara otomatis,silahkan refresh halaman anda)</p>
                                                            <!-- Anda dapat menambahkan isi catatan lainnya sesuai kebutuhan -->
                                                        </div>

                                                        <!-- Bagian Kanan (Form Informasi Peserta) -->
                                                        <div>
                                                            <p class="mb-4">Silakan masukkan informasi peserta.</p>

                                                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                                <div>
                                                                    <label for="kode_pin" class="block text-sm font-medium text-gray-700">Kode PIN (Kode Pendaftaran)</label>
                                                                    <input type="text" x-model="kode_pin" id="kode_pin" placeholder="Kode PIN" readonly class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:border-blue-300" style="background-color: #2D3748; color: #E2E8F0;">
                                                                </div>

                                                                <div>
                                                                    <label for="nama_pendaftar" class="block text-sm font-medium text-gray-700">Nama Siswa</label>
                                                                    <input type="text" x-model="nama_pendaftar" id="nama_pendaftar" placeholder="Nama Siswa" oninput="this.value = this.value.toUpperCase()" class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:border-blue-300">
                                                                </div>

                                                                <div>
                                                                    <label for="nik" class="block text-sm font-medium text-gray-700">NIK</label>
                                                                    <input type="text" x-model="nik" id="nik" placeholder="Nomor NIK" class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:border-blue-300">
                                                                </div>

                                                                <div>
                                                                    <label for="kk" class="block text-sm font-medium text-gray-700">KK</label>
                                                                    <input type="text" x-model="kk" id="kk" placeholder="Nomor KK" class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:border-blue-300">
                                                                </div>

                                                                <div>
                                                                    <label for="tempat_lahir" class="block text-sm font-medium text-gray-700">Tempat Lahir</label>
                                                                    <input type="text" x-model="tempat_lahir" id="tempat_lahir" placeholder="Tempat Lahir" oninput="this.value = this.value.toUpperCase()" class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:border-blue-300">
                                                                </div>

                                                                <div>
                                                                    <label for="tanggal_lahir" class="block text-sm font-medium text-gray-700">Tanggal Lahir</label>
                                                                    <input type="date" x-model="tanggal_lahir" id="tanggal_lahir" placeholder="Tanggal Lahir" class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:border-blue-300">
                                                                </div>

                                                                <div>
                                                                    <label for="no_hp" class="block text-sm font-medium text-gray-700">Nomor HP/WA</label>
                                                                    <input type="text" x-model="no_hp" id="no_hp" placeholder="Nomor HP/WA" class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:border-blue-300">
                                                                </div>

                                                                <div>
                                                                    <label for="jenis_kelamin" class="block text-sm font-medium text-gray-700">Jenis Kelamin</label>
                                                                    <select x-model="jenis_kelamin" id="jenis_kelamin" class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:border-blue-300" required>
                                                                        <option value="">Pilih Jenis Kelamin</option>
                                                                        <option value="Laki-laki">Laki-laki</option>
                                                                        <option value="Perempuan">Perempuan</option>
                                                                    </select>
                                                                </div>

                                                                <div class="col-span-full">
                                                                    <label for="alamat_siswa" class="block text-sm font-medium text-gray-700">Alamat Siswa</label>
                                                                    <textarea x-model="alamat_siswa" id="alamat_siswa" placeholder="Alamat Siswa" class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:border-blue-300"></textarea>
                                                                </div>

                                                                <div>
                                                                    <label for="rt" class="block text-sm font-medium text-gray-700">RT</label>
                                                                    <input type="text" x-model="rt" id="rt" placeholder="RT" class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:border-blue-300">
                                                                </div>

                                                                <div>
                                                                    <label for="rw" class="block text-sm font-medium text-gray-700">RW</label>
                                                                    <input type="text" x-model="rw" id="rw" placeholder="RW" class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:border-blue-300">
                                                                </div>


                                                            </div>

                                                            <!-- Tombol Aksi -->
                                                            <div class="flex justify-end mt-4">
                                                                <button type="button" @click="step = 1" class="bg-gray-500 text-white px-4 py-2 rounded-lg mr-2" x-show="step !== 1">Batal</button>
                                                                <button type="button" @click="step = 2; validateStep1()" x-bind:disabled="!validateStep1()" class="bg-blue-500 text-white px-4 py-2 rounded-lg">Lanjut</button>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <!-- Step 2: Pilihan Jalur Pendaftaran -->
                                                    <div x-show="step === 2" class="grid grid-cols-2 gap-4" style="grid-template-columns: 1fr 2fr;">
                                                        <!-- Pesan Validasi -->
                                                        <div class="col-span-2 mb-4 text-red-500 text-sm" x-show="!validateStep2()">Silakan pilih jalur pendaftaran sebelum melanjutkan.</div>

                                                        <!-- Bagian Kiri (Card Catatan) -->
                                                        <div class="bg-gray-100 p-4 rounded-lg">
                                                            <h3 class="text-lg font-bold mb-2">Catatan:</h3>
                                                            <p class="text-sm" style="color: red; font-weight: bold;">Catat Dan simpan Kode Pin anda !</p>
                                                            <p><br></p>
                                                            <p class="text-sm">Harap diketahui bahwa Kode PIN akan berubah setiap anda merefresh halaman,Bila Kode PIN (Kode Pendaftaran tidak muncul secara otomatis,silahkan refresh halaman anda)</p>
                                                            <!-- Anda dapat menambahkan isi catatan lainnya sesuai kebutuhan -->
                                                        </div>


                                                        <!-- Bagian Kanan (Form Informasi Peserta) -->
                                                        <div>
                                                            <p class="mb-4">Silakan pilih jalur pendaftaran.</p>
                                                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

                                                                <div>
                                                                    <label for="no_skhu" class="block text-sm font-medium text-gray-700">Nomor UN / SKHU</label>
                                                                    <input type="text" x-model="no_skhu" id="no_skhu" placeholder="Nomor UN / SKHU" oninput="this.value = this.value.toUpperCase()" class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:border-blue-300">
                                                                </div>

                                                                <div>
                                                                    <label for="asal_sekolah" class="block text-sm font-medium text-gray-700">Asal Sekolah</label>
                                                                    <input type="text" x-model="asal_sekolah" id="asal_sekolah" placeholder="Asal Sekolah" oninput="this.value = this.value.toUpperCase()" class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:border-blue-300">
                                                                </div>

                                                                <div class="col-span-full">
                                                                    <label for="jalur" class="block text-sm font-medium text-gray-700">Jalur Pendaftaran</label>
                                                                    <select x-model="jalur" class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring focus:border-blue-300" required>
                                                                        <option value="">Pilih Jalur Pendaftaran</option>
                                                                        <?php foreach ($jalur as $item) : ?>
                                                                            <option value="<?= htmlspecialchars($item->id) ?>"><?= htmlspecialchars($item->nama_jalur) ?></option>
                                                                        <?php endforeach; ?>
                                                                    </select>
                                                                </div>

                                                            </div>
                                                            <div class="flex justify-end mt-4">
                                                                <button type="button" @click="step = 1" class="bg-gray-500 text-white px-4 py-2 rounded-lg mr-2">Kembali</button>
                                                                <button type="button" @click="step = 3; validateStep2()" x-bind:disabled="!validateStep2()" class="bg-blue-500 text-white px-4 py-2 rounded-lg">Lanjut</button>
                                                            </div>
                                                        </div>
                                                    </div>






                                                    <!-- Step 3: Informasi Orang Tua -->
                                                    <div x-show="step === 3">
                                                        <!-- Pesan Validasi -->
                                                        <div class="mb-4 text-red-500 text-sm" x-show="!validateStep3()">Silakan lengkapi informasi orang tua sebelum melanjutkan.</div>

                                                        <p class="mb-4">Silakan masukkan informasi orang tua.</p>
                                                        <div class="grid grid-cols-2 gap-4">
                                                            <input type="text" x-model="nama_orang_tua" placeholder="Nama Orang Tua" oninput="this.value = this.value.toUpperCase()" class="w-full mb-4 px-4 py-2 border rounded-lg">
                                                            <input type="text" x-model="no_telp_orang_tua" placeholder="Nomor Telepon Orang Tua" class="w-full mb-4 px-4 py-2 border rounded-lg">
                                                        </div>

                                                        <div class="flex justify-end">
                                                            <button type="button" @click="step = 2" class="bg-gray-500 text-white px-4 py-2 rounded-lg mr-2">Kembali</button>
                                                            <button type="button" @click="step = 4; validateStep3()" x-bind:disabled="!validateStep3()" class="bg-blue-500 text-white px-4 py-2 rounded-lg">Lanjut</button>
                                                        </div>
                                                    </div>

                                                    <div x-show="step === 4">
                                                        <p class="mb-4">Pastikan semua informasi yang Anda masukkan sudah benar sebelum melanjutkan.</p>

                                                        <!-- Checkbox Persetujuan -->
                                                        <div class="flex items-center mb-4">
                                                            <input type="checkbox" id="setuju" x-model="setuju" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                                            <label for="setuju" class="ml-2 block text-sm text-gray-900">Saya menyetujui untuk melakukan finalisasi data.</label>
                                                        </div>

                                                        <!-- Tombol Aksi -->
                                                        <div class="flex justify-end">
                                                            <button type="button" @click="step = 3" class="bg-gray-500 text-white px-4 py-2 rounded-lg mr-2">Kembali</button>
                                                            <button type="button" @click="simpanData()" :disabled="!setuju" class="bg-blue-500 text-white px-4 py-2 rounded-lg">Daftar</button>
                                                        </div>
                                                    </div>


                                                    <!-- Step 5: Selesai -->
                                                    <div x-show="step === 5" class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                                                        <strong class="font-bold">Terima kasih!</strong>
                                                        <span class="block sm:inline">Anda telah menyelesaikan proses pendaftaran,Silahkan Cetak Bukti Pendaftaran pada menu (cetak bukti)</span>
                                                        <div class="flex justify-end mt-4">
                                                            <!--  <button type="button" @click="step = 1; clearForm()" class="bg-gray-500 text-white px-4 py-2 rounded-lg mr-2">Daftar Lagi</button>-->
                                                        </div>
                                                    </div>
                                                </form>



                                            </div>
                                        </div>
                                    </div>
                                </div>









                                <a class=" inline-flex items-center justify-center rounded-lg focus:outline-none focus-visible:ring shadow-sm transition-colors duration-75 min-h-[3rem] px-3.5 md:min-h-[2.75rem] text-base text-typo border border-gray-300 hover:bg-light focus-visible:ring-primary-400 active:bg-typo-divider disabled:bg-typo-divider disabled:cursor-not-allowed font-averta font-medium" href="#">
                                    <div class="mr-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-megaphone text-base">
                                            <path d="m3 11 18-5v12L3 14v-3z"></path>
                                            <path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"></path>
                                        </svg>
                                    </div>Baca Pengumuman
                                </a>
                            </div>
                        </div>
                        <div class="relative flex h-full w-full items-center @container">
                            <div class="absolute left-0 top-0 z-20 block w-full max-w-xs origin-top-left -translate-y-1/2 scale-75 md:hidden">
                                <div class="flex items-center gap-4 rounded-full bg-white p-4 pr-8 shadow-2xl">
                                    <div class="w-16 rounded-full bg-primary-100 p-3">
                                        <figure class="w-full"><img alt="Logo Pemerintah Provinsi Jawa TImur" loading="lazy" width="824" height="900" decoding="async" data-nimg="1" class style="color:transparent" src="<?php echo base_url() ?>assets/web/<?php echo $res->logo; ?>" /></figure>
                                    </div>
                                    <div>
                                        <p class="text-base text-typo font-averta font-semibold">Dinas Pendidikan</p>
                                        <p class="text-sm font-medium text-typo-secondary font-averta">Pemerintah Provinsi Jawa Timur</p>
                                    </div>
                                </div>
                            </div>
                            <div class="relative z-10 flex w-full justify-center">
                                <div class="group max-w-sm rounded-3xl bg-white p-2 w-[80%]">
                                    <div class="slick-slider aspect-[9/8] cursor-grab overflow-hidden rounded-2xl slick-initialized" dir="ltr"><button class="justify-center font-medium focus:outline-none focus-visible:ring shadow-sm min-h-[1.75rem] min-w-[1.75rem] md:min-h-[2rem] md:min-w-[2rem] text-xs md:text-sm text-typo border border-gray-300 hover:bg-light focus-visible:ring-primary-400 active:bg-typo-divider disabled:bg-typo-divider disabled:cursor-not-allowed left-2 top-1/2 -translate-y-1/2 absolute z-10 flex items-center transition-all duration-200 rounded-full bg-white opacity-0 group-hover:opacity-100" type="button"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-left">
                                                <path d="m15 18-6-6 6-6"></path>
                                            </svg></button>
                                        <div class="slick-list">
                                            <div class="slick-track" style="width:700%;left:-100%">
                                                <div data-index="-1" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:14.285714285714286%">
                                                    <div>
                                                        <div class="relative aspect-[9/8] bg-inherit text-center" tabindex="-1" style="width:100%;display:inline-block">
                                                            <figure class="absolute inset-0 w-full"><img alt="Foto PPDB Jatim" loading="lazy" width="720" height="634" decoding="async" data-nimg="1" class="object-cover w-full h-full animate-pulse" style="color:transparent" src="https://cdn.excode.my.id/assets/landing/ppdb/img/carousel-image-3.jpg" /></figure>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div data-index="0" class="slick-slide slick-active slick-current" tabindex="-1" aria-hidden="false" style="outline:none;width:14.285714285714286%">
                                                    <div>
                                                        <div class="relative aspect-[9/8] bg-inherit text-center" tabindex="-1" style="width:100%;display:inline-block">
                                                            <figure class="absolute inset-0 w-full"><img alt="Foto PPDB Jatim" loading="lazy" width="720" height="634" decoding="async" data-nimg="1" class="object-cover w-full h-full animate-pulse" style="color:transparent" src="https://cdn.excode.my.id/assets/landing/ppdb/img/carousel-image-1.jpg" /></figure>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div data-index="1" class="slick-slide" tabindex="-1" aria-hidden="true" style="outline:none;width:14.285714285714286%">
                                                    <div>
                                                        <div class="relative aspect-[9/8] bg-inherit text-center" tabindex="-1" style="width:100%;display:inline-block">
                                                            <figure class="absolute inset-0 w-full"><img alt="Foto PPDB Jatim" loading="lazy" width="720" height="634" decoding="async" data-nimg="1" class="object-cover w-full h-full animate-pulse" style="color:transparent" src="https://cdn.excode.my.id/assets/landing/ppdb/img/carousel-image-2.jpg" /></figure>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div data-index="2" class="slick-slide" tabindex="-1" aria-hidden="true" style="outline:none;width:14.285714285714286%">
                                                    <div>
                                                        <div class="relative aspect-[9/8] bg-inherit text-center" tabindex="-1" style="width:100%;display:inline-block">
                                                            <figure class="absolute inset-0 w-full"><img alt="Foto PPDB Jatim" loading="lazy" width="720" height="634" decoding="async" data-nimg="1" class="object-cover w-full h-full animate-pulse" style="color:transparent" src="https://cdn.excode.my.id/assets/landing/ppdb/img/carousel-image-3.jpg" /></figure>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div data-index="3" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:14.285714285714286%">
                                                    <div>
                                                        <div class="relative aspect-[9/8] bg-inherit text-center" tabindex="-1" style="width:100%;display:inline-block">
                                                            <figure class="absolute inset-0 w-full"><img alt="Foto PPDB Jatim" loading="lazy" width="720" height="634" decoding="async" data-nimg="1" class="object-cover w-full h-full animate-pulse" style="color:transparent" src="https://cdn.excode.my.id/assets/landing/ppdb/img/carousel-image-1.jpg" /></figure>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div data-index="4" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:14.285714285714286%">
                                                    <div>
                                                        <div class="relative aspect-[9/8] bg-inherit text-center" tabindex="-1" style="width:100%;display:inline-block">
                                                            <figure class="absolute inset-0 w-full"><img alt="Foto PPDB Jatim" loading="lazy" width="720" height="634" decoding="async" data-nimg="1" class="object-cover w-full h-full animate-pulse" style="color:transparent" src="https://cdn.excode.my.id/assets/landing/ppdb/img/carousel-image-2.jpg" /></figure>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div data-index="5" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:14.285714285714286%">
                                                    <div>
                                                        <div class="relative aspect-[9/8] bg-inherit text-center" tabindex="-1" style="width:100%;display:inline-block">
                                                            <figure class="absolute inset-0 w-full"><img alt="Foto PPDB Jatim" loading="lazy" width="720" height="634" decoding="async" data-nimg="1" class="object-cover w-full h-full animate-pulse" style="color:transparent" src="https://cdn.excode.my.id/assets/landing/ppdb/img/carousel-image-3.jpg" /></figure>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><button class="justify-center font-medium focus:outline-none focus-visible:ring shadow-sm min-h-[1.75rem] min-w-[1.75rem] md:min-h-[2rem] md:min-w-[2rem] text-xs md:text-sm text-typo border border-gray-300 hover:bg-light focus-visible:ring-primary-400 active:bg-typo-divider disabled:bg-typo-divider disabled:cursor-not-allowed right-2 top-1/2 -translate-y-1/2 absolute z-10 flex items-center transition-all duration-200 rounded-full bg-white opacity-0 group-hover:opacity-100" type="button"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-right">
                                                <path d="m9 18 6-6-6-6"></path>
                                            </svg></button>
                                    </div>
                                    <div class="mt-2 flex justify-center gap-2"><button class="inline-flex items-center justify-center rounded-lg font-medium focus:outline-none focus-visible:ring shadow-sm text-sm md:text-base text-typo border border-gray-300 focus-visible:ring-primary-400 active:bg-typo-divider disabled:bg-typo-divider disabled:cursor-not-allowed h-2 w-2 px-0 transition-all duration-200 min-h-0 hover:bg-typo-outline md:min-h-0 bg-typo-outline" type="button"></button><button class="inline-flex items-center justify-center rounded-lg font-medium focus:outline-none focus-visible:ring shadow-sm text-sm md:text-base text-typo border focus-visible:ring-primary-400 active:bg-typo-divider disabled:bg-typo-divider disabled:cursor-not-allowed h-2 w-2 px-0 transition-all duration-200 min-h-0 hover:bg-typo-outline md:min-h-0 border-transparent bg-typo-divider bg-opacity-50" type="button"></button><button class="inline-flex items-center justify-center rounded-lg font-medium focus:outline-none focus-visible:ring shadow-sm text-sm md:text-base text-typo border focus-visible:ring-primary-400 active:bg-typo-divider disabled:bg-typo-divider disabled:cursor-not-allowed h-2 w-2 px-0 transition-all duration-200 min-h-0 hover:bg-typo-outline md:min-h-0 border-transparent bg-typo-divider bg-opacity-50" type="button"></button></div>
                                </div>
                                <div class="absolute bottom-0 right-0 hidden w-[calc(100%*5/12)] max-w-xs translate-y-1/3 md:block">
                                    <div class="flex flex-col gap-4 rounded-lg bg-white p-4 shadow-xl">
                                        <div class="flex items-center gap-4 ">
                                            <div class="inline-flex h-6 w-6 items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-globe">
                                                    <circle cx="12" cy="12" r="10"></circle>
                                                    <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"></path>
                                                    <path d="M2 12h20"></path>
                                                </svg></div>
                                            <h5 class="font-averta text-base font-semibold text-typo">Tentang Situs</h5>
                                        </div>
                                        <div class="rounded-md bg-primary-100 p-3">
                                            <p class="text-sm font-medium font-averta text-primary-500">Layanan sistem informasi PPDB Online <br><?php echo $res->nama_lembaga; ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="absolute bottom-0 left-0 top-0 hidden h-fit max-w-xs -translate-x-0 -translate-y-1/2 md:block ">
                                    <div class="flex items-center gap-2 rounded-full bg-white p-4 pr-8 shadow-2xl">
                                        <div class="w-16 rounded-full bg-primary-100 p-3">
                                            <figure class="w-full"><img alt="Logo Pemerintah Provinsi Jawa TImur" loading="lazy" width="824" height="900" decoding="async" data-nimg="1" class style="color:transparent" src="<?php echo base_url() ?>assets/web/<?php echo $res->logo; ?>" /></figure>
                                        </div>
                                        <div>
                                            <p class="text-base text-typo font-averta font-semibold">Portal Pendaftaran</p>
                                            <p class="text-sm font-medium text-typo-secondary font-averta"><?php echo $res->nama_lembaga; ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="pointer-events-none absolute inset-0 flex z-0">
                                <div class="absolute left-1/2 top-1/2 z-10 aspect-square w-full -translate-x-1/2 -translate-y-1/2">
                                    <figure class="absolute inset-0 z-0 w-full"><img alt="Circle" loading="lazy" width="721" height="721" decoding="async" data-nimg="1" class="object-cover w-full h-full" style="color:transparent" src="https://cdn.excode.my.id/assets/landing/ppdb/img/circle.svg" /></figure>
                                    <div class="absolute inset-0 w-full animate-[spin_180s_linear_infinite] motion-reduce:animate-none">
                                        <figure class="absolute right-0 top-1/4 w-8 animate-[spin_50s_linear_infinite] md:w-16"><img alt="particle" loading="lazy" width="256" height="256" decoding="async" data-nimg="1" class style="color:transparent" src="https://cdn.excode.my.id/assets/landing/ppdb/img/ring-dark-purple.png" /></figure>
                                    </div>
                                    <div class="absolute inset-0 w-full animate-[spin_200s_linear_infinite] motion-reduce:animate-none">
                                        <figure class="absolute left-1/4 top-0 z-20 w-8 animate-[spin_70s_linear_infinite] md:w-16"><img alt="particle" loading="lazy" width="256" height="256" decoding="async" data-nimg="1" class style="color:transparent" src="https://cdn.excode.my.id/assets/landing/ppdb/img/cube-green-rounded.png" /></figure>
                                    </div>
                                    <div class="absolute inset-0 w-full animate-[spin_150s_linear_infinite] motion-reduce:animate-none">
                                        <figure class="absolute bottom-0 left-1/4 w-8 animate-[spin_10s_linear_infinite] md:w-16"><img alt="particle" loading="lazy" width="256" height="256" decoding="async" data-nimg="1" class style="color:transparent" src="https://cdn.excode.my.id/assets/landing/ppdb/img/sphere-green.png" /></figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="pointer-events-none absolute inset-0 bg-noise mix-blend-overlay"></div>
                </section>
                <section class="relative flex py-16 bg-light">
                    <div class="z-10 flex flex-col items-center layout">
                        <div class="max-w-xl text-center">
                            <h1 class="font-averta text-4xl text-typo font-semibold md:text-6xl text-balance">Statistik PPDB <br><?php echo $res->nama_lembaga; ?></h1>
                            <div class="mt-6">
                                <div class="animate-shimmer bg-[#f6f7f8] w-20 h-5 rounded-full" style="background-image:linear-gradient(to right, #f6f7f8 0%, #edeef1 20%, #f6f7f8 40%, #f6f7f8 100%);background-size:700px 100%;background-repeat:no-repeat"></div>
                            </div>
                        </div>
                        <div class="flex flex-col w-full max-w-4xl gap-4 mt-8">
                            <div class="bg-white shadow-sm p-5 rounded-xl relative flex gap-5 overflow-hidden">
                                <div class="absolute inset-x-0 top-0 md:relative h-4 md:h-full w-full md:w-3 rounded-none md:rounded-full bg-orange-300">&nbsp;</div>
                                <div class="flex flex-col w-full gap-8 mt-4 md:mt-0 md:flex-row md:items-center">
                                    <div class="w-full">
                                        <h2 class="font-averta text-xl font-semibold text-typo">Peserta Mendapatkan PIN</h2>
                                    </div>
                                    <div class="flex gap-3 shrink-0"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-user-round mt-1 shrink-0 text-typo">
                                            <path d="M18 20a6 6 0 0 0-12 0"></path>
                                            <circle cx="12" cy="10" r="4"></circle>
                                            <circle cx="12" cy="12" r="10"></circle>
                                        </svg>
                                        <div class="">
                                            <dt class="text-sm font-normal text-typo-secondary">Jumlah Siswa</dt>
                                            <dd class="text-base text-typo"><?php echo $total_pendaftar; ?><span class="b3 text-typo-secondary"> Siswa</span></dd>
                                        </div>
                                    </div>
                                    <div class="w-full mt-1 space-y-1">
                                        <div class="relative h-2 overflow-hidden rounded-full shadow-inner w-ful bg-light"><span class="bg-orange-300 absolute left-0 h-2 shrink-0 rounded-r-full" title="Peserta Mendapatkan PIN" style="width: 98.3199%;">&nbsp;</span></div>
                                        <div class="flex justify-end w-full">
                                            <p class="text-sm font-normal text-typo-tertiary">98.32%</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php foreach ($jalurppdb as $jalurppdb) { ?>
                                <div class="bg-white shadow-sm p-5 rounded-xl relative flex gap-5 overflow-hidden">
                                    <div class="absolute inset-x-0 top-0 md:relative h-4 md:h-full w-full md:w-3 rounded-none md:rounded-full bg-green-300">&nbsp;</div>
                                    <div class="flex flex-col w-full gap-8 mt-4 md:mt-0 md:flex-row md:items-center">
                                        <div class="w-full">
                                            <h2 class="font-averta text-xl font-semibold text-typo">Total Pendaftar <?php echo $jalurppdb->nama_jalur; ?></h2>
                                        </div>
                                        <div class="flex gap-3 shrink-0"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-user-round mt-1 shrink-0 text-typo">
                                                <path d="M18 20a6 6 0 0 0-12 0"></path>
                                                <circle cx="12" cy="10" r="4"></circle>
                                                <circle cx="12" cy="12" r="10"></circle>
                                            </svg>
                                            <div class="">
                                                <dt class="text-sm font-normal text-typo-secondary">Siswa Pendaftar</dt>
                                                <dd class="text-base text-typo"><?php echo $jalurppdb->siswa_pendaftar; ?></dd>
                                            </div>
                                        </div>
                                        <div class="flex gap-3 shrink-0"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-user-round mt-1 shrink-0 text-typo">
                                                <path d="M18 20a6 6 0 0 0-12 0"></path>
                                                <circle cx="12" cy="10" r="4"></circle>
                                                <circle cx="12" cy="12" r="10"></circle>
                                            </svg>
                                            <div class="">
                                                <dt class="text-sm font-normal text-typo-secondary">Kouta Penerimaan</dt>
                                                <dd class="text-base text-typo"><?php echo $jalurppdb->kouta; ?></dd>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="absolute inset-0 " style="background-image:url(https://cdn.excode.my.id/assets/landing/ppdb/img/grid.png">
                        <div class="absolute inset-0 bg-repeat bg-gradient-to-b from-light to-transparent"></div>
                    </div>
                </section>
                <footer class="relative bg-light print:hidden"><span class="sr-only">Footer</span>
                    <div class="layout py-16">
                        <div class="xl:grid xl:grid-cols-3 xl:gap-8">
                            <div class="space-y-8 xl:col-span-1"><a class="focus:outline-none focus-visible:ring focus-visible:ring-primary-500 focus-visible:ring-opacity-75" href="/"><span class="sr-only">PPDB Jawa Timur <!-- -->2024</span>
                                    <figure class="w-9 md:w-12"><img alt="Logo Pemerintah Provinsi Jawa TImur" loading="lazy" width="824" height="900" decoding="async" data-nimg="1" class style="color:transparent" src="<?php echo base_url() ?>assets/web/<?php echo $res->logo; ?>" /></figure>
                                </a>
                                <p class="text-lg text-typo-tertiary font-averta">Portal Penerimaan Peserta Didik Baru (PPDB) <?php echo $res->nama_lembaga; ?></p>
                            </div>
                            <div class="mt-12 grid grid-cols-2 gap-8 xl:col-span-2 xl:mt-0">
                                <div>
                                    <h1 class="text-sm text-typo-tertiary font-averta font-semibold uppercase tracking-widest">Informasi</h1>
                                    <ul role="list" class="mt-4 space-y-4">
                                        <li><a href="/informasi/ketentuan/">
                                                <p class="text-base text-typo-tertiary font-averta hover:text-typo-secondary">Ketentuan</p>
                                            </a></li>
                                        <li><a href="/informasi/prosedur/">
                                                <p class="text-base text-typo-tertiary font-averta hover:text-typo-secondary">Prosedur</p>
                                            </a></li>
                                        <li><a href="/informasi/jadwal/">
                                                <p class="text-base text-typo-tertiary font-averta hover:text-typo-secondary">Jadwal</p>
                                            </a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="mt-12 border-t border-typo-divider pt-8">
                            <p class="text-base text-typo-tertiary font-averta xl:text-center">© <?php echo $res->nama_lembaga; ?></p>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script id="__NEXT_DATA__" type="application/json">
        {
            "props": {
                "pageProps": {}
            },
            "page": "/",
            "query": {},
            "buildId": "sftvS_KYbAS2JuN9SeZiU",
            "nextExport": true,
            "autoExport": true,
            "isFallback": false,
            "scriptLoader": []
        }
    </script>

    <script src="https://cdn.excode.my.id/assets/landing/ppdb/rocket-loader.min.js'); ?>" data-cf-settings="f3e77268fe13094b7f956059-|49" defer></script>

    <script>
        (function() {
            function c() {
                var b = a.contentDocument || a.contentWindow.document;
                if (b) {
                    var d = b.createElement('script');
                    d.innerHTML = "window.__CF$cv$params={r:'897b269afbcf48d0',t:'MTcxOTA0NzkwNC4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='https://cdn.excode.my.id/assets/landing/ppdb/main.js'); ?>';document.getElementsByTagName('head')[0].appendChild(a);";
                    b.getElementsByTagName('head')[0].appendChild(d)
                }
            }
            if (document.body) {
                var a = document.createElement('iframe');
                a.height = 1;
                a.width = 1;
                a.style.position = 'absolute';
                a.style.top = 0;
                a.style.left = 0;
                a.style.border = 'none';
                a.style.visibility = 'hidden';
                document.body.appendChild(a);
                if ('loading' !== document.readyState) c();
                else if (window.addEventListener) document.addEventListener('DOMContentLoaded', c);
                else {
                    var e = document.onreadystatechange || function() {};
                    document.onreadystatechange = function(b) {
                        e(b);
                        'loading' !== document.readyState && (document.onreadystatechange = e, c())
                    }
                }
            }
        })();
    </script>
    <script>
        $(document).ready(function() {
            $('#dropdown-toggle-desktop').mouseenter(function() {
                $('#dropdown-menu-information').removeClass('hidden');
            });

            $('#dropdown-toggle-desktop').mouseleave(function() {
                $('#dropdown-menu-information').addClass('hidden');
            });

            $('#dropdown-menu-information').mouseenter(function() {
                $(this).removeClass('hidden');
            });

            $('#dropdown-menu-information').mouseleave(function() {
                $(this).addClass('hidden');
            });
        });
    </script>
    <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"rayId":"897b269afbcf48d0","r":1,"version":"2024.4.1","token":"92818cf595684c5a8d904bd478ef0ac9"}' crossorigin="anonymous"></script>
</body>

</html>