<html lang="en">

<head>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

   <?php $this->load->view('ptk/_partials/head.php') ?>

   <style>
      @keyframes blink {
         0% {
            opacity: 1;
         }

         50% {
            opacity: 0;
         }

         100% {
            opacity: 1;
         }
      }

      .blink {
         animation: blink 3s infinite;
      }
   </style>
   <style>
      .accordion-button {
         color: #ffffff;
         /* Ubah warna teks sesuai kebutuhan */
         background-color: #007bff;
         /* Warna latar belakang tombol */
         border-color: #007bff;
         /* Warna border tombol */
      }

      .accordion-button:focus,
      .accordion-button:hover {
         color: #ffffff;
         /* Warna teks saat tombol mendapatkan fokus atau hover */
         background-color: #0056b3;
         /* Warna latar belakang saat tombol mendapatkan fokus atau hover */
         border-color: #0056b3;
         /* Warna border saat tombol mendapatkan fokus atau hover */
      }

      .accordion-button.collapsed {
         color: #000000;
         /* Warna teks saat tombol dalam keadaan collapsed */
         background-color: #f8f9fa;
         /* Warna latar belakang saat tombol dalam keadaan collapsed */
         border-color: #f8f9fa;
         /* Warna border saat tombol dalam keadaan collapsed */
      }

      .accordion-button.collapsed:focus,
      .accordion-button.collapsed:hover {
         color: #000000;
         /* Warna teks saat tombol dalam keadaan collapsed mendapatkan fokus atau hover */
         background-color: #e2e6ea;
         /* Warna latar belakang saat tombol dalam keadaan collapsed mendapatkan fokus atau hover */
         border-color: #dae0e5;
         /* Warna border saat tombol dalam keadaan collapsed mendapatkan fokus atau hover */
      }
   </style>
</head>

<body>

   <body class="hold-transition sidebar-mini layout-fixed layout-footer-fixed">
      <div class="wrapper">
         <?php $this->load->view('ptk/_partials/navbar.php') ?>
         <aside class="main-sidebar elevation-4 sidebar-dark-<?php echo $profilsekolah['menu_active'] ?? ''; ?>" style="background-color: <?php echo $profilsekolah['bg_active'] ?? ''; ?>;">
            <?php $this->load->view('ptk/_partials/sidebar_information.php') ?>
            <?php $this->load->view('ptk/_partials/sidebar_menu.php') ?>
         </aside>
         <!-- Content Wrapper. Contains page content -->
         <div class="content-wrapper" style="min-height: 1200px;">
            <div class="content-header">
               <div class="container-fluid">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="card">
                           <div class="card-body">
                              <marquee behavior="scroll" direction="left" scrollamount="4">
                                 <p class="card-text">
                                    Halo, Selamat datang di dashboard SmartSchool, tempat di mana kamu dapat mengeksplorasi dunia pendidikan dengan lebih menyenangkan dan interaktif. Di sini, kamu dapat melihat jadwal pelajaran, tugas yang harus diselesaikan, informasi tentang kegiatan sekolah, dan masih banyak lagi.
                                 </p>
                              </marquee>
                           </div>
                        </div>
                     </div>
                  </div>


                  <div class="row">
                     <div class="col-lg-9">
                        <div class="card">
                           <div class="card-body">
                              <div class="row">
                                 <div class="col-12 col-sm-6 col-md-6 d-flex align-items-stretch">
                                    <div class="info-box bg-info flex-fill">
                                       <span class="info-box-icon elevation-5" style="color: #ffffff;"><i class="fas fa-user-graduate"></i></span>
                                       <div class="info-box-content elevation-4" style="background-color: #FFFFFF; color: #000000;">
                                          <span class="info-box-text font-weight-bold">Data Guru</span>
                                          <span class="info-box-number"><?php echo $dataguru['nama_ptk']; ?></span>
                                          NIP : <?php echo $dataguru['nip']; ?>
                                          <span class="info-box-text">Data masuk ke dalam database</span>
                                       </div>
                                    </div>
                                 </div>


                                 <div class="col-12 col-sm-6 col-md-6 d-flex align-items-stretch">
                                    <div class="info-box bg-info flex-fill d-flex align-items-center justify-content-between">
                                       <a class="btn btn-danger mr-3" href="#" onclick="generateQR(<?php echo $dataguru['id_guru']; ?>)"><i class="fas fa-qrcode"></i> Generate QR</a>
                                       <div class="info-box-content elevation-4" style="background-color: #FFFFFF; color: #000000; display: flex; flex-direction: column; align-items: center;">
                                          <span class="info-box-text font-weight-bold">QR CODE</span>
                                          <?php if (!empty($dataguru['qrcode_ptk'])) : ?>
                                             <img src="<?php echo base_url($dataguru['qrcode_ptk']); ?>" style="max-width: 100px; height: auto;" id="qrcode_<?php echo $dataguru['id_guru']; ?>" />
                                          <?php else : ?>
                                             <img src="https://cdn.excode.my.id/assets/material/placeholderupload.jpg" style="max-width: 100px; height: auto;" id="qrcode_<?php echo $dataguru['id_guru']; ?>" />
                                          <?php endif; ?>
                                       </div>
                                    </div>
                                 </div>

                              </div>
                           </div>
                        </div>
                     </div>

                     <div class="col-lg-3" style="height: 170px;">
                        <div class="card">
                           <div class="card-body">
                              <div class="row">
                                 <div class="col-12 col-sm-6 col-md-12">
                                    <div class="info-box bg-info">
                                       <div class="info-box-content elevation-4" style="background-color: #FFFFFF; color: #000000; height: 40px;">
                                          <span class="info-box-text font-weight-bold"><i class="fas fa-chalkboard"></i> Daftar Kelas Mengajar</span>
                                       </div>
                                    </div>
                                 </div>

                                 <?php foreach ($kelas as $k) : ?>
                                    <?php $class_color = $this->Ptk->count_siswa_by_kelas($k['no_kelas']) > 0 ? 'bg-success' : 'bg-secondary'; ?>
                                    <div class="col-md-4 mb-1">
                                       <button type="button" class="list-group-item list-group-item-action kelas font-weight-bold text-white <?php echo $class_color; ?>" data-id="<?php echo $k['no_kelas']; ?>">
                                          <i class="fas fa fa-barcode" style="font-size: 9px;"></i> <?php echo $k['nama_kelas']; ?>
                                       </button>
                                    </div>
                                 <?php endforeach; ?>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>



                  <div class="row">
                     <div class="col-lg-6">
                        <div class="card">
                           <div class="card-body">
                              <div class="row">
                                 <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel" data-bs-interval="3000">
                                    <div class="carousel-inner">
                                       <div class="carousel-item active">
                                          <img src="https://cdn.excode.my.id/assets/slide/slide1.jpg" class="d-block w-100" width="800" height="400">
                                       </div>
                                       <div class="carousel-item">
                                          <img src="https://cdn.excode.my.id/assets/slide/slide2.png" class="d-block w-100" width="800" height="400">
                                       </div>
                                       <div class="carousel-item">
                                          <img src="https://cdn.excode.my.id/assets/slide/slide3.png" class="d-block w-100" width="800" height="400">
                                       </div>
                                    </div>
                                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                       <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                       <span class="visually-hidden">Previous</span>
                                    </button>
                                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                       <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                       <span class="visually-hidden">Next</span>
                                    </button>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-3">
                        <div class="card">
                           <div class="card-body">
                              <div class="row">
                                 <div class="col-12 col-sm-6 col-md-12">
                                    <div class="info-box bg-secondary">
                                       <div class="info-box-content elevation-4" style="background-color: #FFFFFF; color: #000000; height: 40px;">
                                          <span class="info-box-text font-weight-bold "><i class="fas fa-bullhorn"></i> Pengumuman</span>
                                       </div>
                                    </div>
                                 </div>
                              </div>






                              <div class="accordion" id="accordionExample">
                                 <div class="accordion-item">
                                    <h2 class="accordion-header">
                                       <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                          Panduan &nbsp;<strong>SMARTSCHOOL</strong>
                                       </button>
                                    </h2>
                                    <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                                       <div class="accordion-body">
                                          <strong>Kelas Mengajar</strong> Daftar Kelas mengajar akan muncul secara otomatis sesuai dengan konfigurasi yang dilakukan oleh operator/admin sekolah
                                       </div>
                                    </div>
                                 </div>
                                 <div class="accordion-item">
                                    <h2 class="accordion-header">
                                       <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#kehadiransiswa" aria-expanded="false" aria-controls="collapseTwo">
                                          Kehadiran Siswa
                                       </button>
                                    </h2>
                                    <div id="kehadiransiswa" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                       <div class="accordion-body">
                                          Setiap Guru Bisa Melihat daftar hadir siswanya berdasarkan kelas yang diajar
                                       </div>
                                    </div>
                                 </div>
                                 <div class="accordion-item">
                                    <h2 class="accordion-header">
                                       <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#bukudigital" aria-expanded="false" aria-controls="collapseTwo">
                                          Buku Digital
                                       </button>
                                    </h2>
                                    <div id="bukudigital" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                       <div class="accordion-body">
                                          Setiap PTK bisa melakukan upload bahan ajar / buku elektronik ke kelas masing-masing untuk di akses oleh para siswa
                                       </div>
                                    </div>
                                 </div>
                                 <div class="accordion-item">
                                    <h2 class="accordion-header">
                                       <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                          Panduan Penggunaan
                                       </button>
                                    </h2>
                                    <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                       <div class="accordion-body">
                                          <strong>SMARTSCHOOL</strong> dirancang untuk memudahkan pembelajaran secara digital, baik berupa pengelolaan pengadministrasian lembaga sampai dengan media pembelajaran berbasis online
                                       </div>
                                    </div>
                                 </div>
                              </div>




                           </div>

                        </div>
                     </div>
                  </div>



               </div>
            </div>
            <!-- isi content -->
            <div class="content">
               <div class="container-fluid">

                  <div class="row">
                     <div class="col-lg-7">

                        <div class="card">










                        </div>











                     </div>



                  </div>
               </div>



            </div>
         </div>
      </div>



      <script>
         // Function untuk generate QR Code menggunakan AJAX
         function generateQR(id_guru) {
            $.ajax({
               url: '<?php echo base_url('ptk/dashboard/generate_qr_code/'); ?>' + id_guru,
               type: 'GET',
               dataType: 'json', // Tambahkan dataType: 'json' untuk menerima respons JSON
               success: function(response) {
                  if (response.success) {
                     // Tampilkan QR Code di tempat yang diinginkan
                     $('#qrcode_' + id_guru).attr('src', response.qr_code_path);
                     // Tampilkan toast berhasil
                     showToast('success', 'QR Code berhasil di-generate');
                  } else {
                     // Tampilkan pesan error
                     showToast('error', response.message);
                  }
               },
               error: function(xhr, status, error) {
                  console.error(xhr.responseText);
                  showToast('error', 'Gagal meng-generate QR Code');
               }
            });
         }

         // Function untuk menampilkan toast messages
         function showToast(type, message) {
            toastr.options.positionClass = 'toast-top-right';
            toastr[type](message);
         }
      </script>

      <script>
         document.addEventListener("DOMContentLoaded", function() {
            var ctx = document.getElementById('Chartkandang').getContext('2d');
            var Chartkandang = new Chart(ctx, {
               type: 'doughnut', // Mengubah tipe chart menjadi pie
               data: {
                  labels: [
                     <?php foreach ($kandang_chart as $kandang) : ?> "<?php echo $kandang['nama_kandang']; ?>",
                     <?php endforeach; ?>
                  ],
                  datasets: [{
                     label: 'Jumlah Ayam',
                     data: [
                        <?php foreach ($kandang_chart as $kandang) : ?>
                           <?php echo $kandang['jumlah_ayam']; ?>,
                        <?php endforeach; ?>
                     ],
                     backgroundColor: [
                        'rgb(238, 0, 123)',
                        'rgb(4, 117, 135)',
                        'rgb(238, 141, 0)',
                        'rgb(7, 126, 105)'


                        // Tambahkan warna lain jika diperlukan
                     ],

                     borderColor: [
                        'rgb(238, 0, 123)',
                        'rgb(4, 117, 135)',
                        'rgb(238, 141, 0)',
                        'rgb(7, 126, 105)'
                        // Tambahkan warna lain jika diperlukan
                     ],
                     borderWidth: 1
                  }]
               },
               options: {
                  responsive: true,
                  maintainAspectRatio: false, // Untuk memungkinkan perubahan aspek rasio
                  scales: {
                     yAxes: [{
                        ticks: {
                           beginAtZero: true
                        }
                     }]
                  }
               }
            });
         });
      </script>


      <script>
         //grafik performa menghitung pendapatan butir telur harian 
         // Ambil data dari PHP dan konversi ke JavaScript
         var grafik_tanggal = <?php echo json_encode($grafik_tanggal); ?>;
         var grafik_jumlah_butir_telur = <?php echo json_encode($grafik_jumlah_butir_telur); ?>;

         // Buat grafik dengan Chart.js
         var ctx = document.getElementById('grafikButirTelur').getContext('2d');
         var myChart = new Chart(ctx, {
            type: 'line',
            data: {
               labels: grafik_tanggal,
               datasets: [{
                  label: 'Jumlah Butir Telur',
                  data: grafik_jumlah_butir_telur,
                  backgroundColor: 'rgba(54, 162, 235, 0.2)',
                  borderColor: 'rgba(54, 162, 235, 1)',
                  borderWidth: 1
               }]
            },
            options: {
               scales: {
                  yAxes: [{
                     ticks: {
                        beginAtZero: true
                     }
                  }]
               }
            }
         });
      </script>







      <!-- ======================================================================================================= -->
      <!-- Footer -->
      <?php $this->load->view('ptk/_partials/footer.php') ?>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>